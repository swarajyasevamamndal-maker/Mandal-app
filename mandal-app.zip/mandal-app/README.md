# देवी मंडळ / Mandal App — Complete Setup Guide

तीन गोष्टींसाठी हा README आहे: **(1) Android APK कसा बनवायचा, (2) Backend कुठे deploy करायचा, (3) संपूर्ण project कसा तपासायचा.**

---

---

## Part 0 — Phone-Only Path (no PC/Android Studio needed)

Mobile browsers can't upload a nested folder structure (this is an Android/browser limitation, not a user error), so this path uploads **one single file** — `mandal-app.zip` itself, committed as-is to the repo root — and lets GitHub's cloud build servers unzip and build everything.

- `.github/workflows/build-apk.yml` — unzips `mandal-app.zip` itself as its first step, then builds the debug APK and attaches it to a GitHub Release (a direct downloadable `.apk` link, no manual unzip needed on your end)
- Backend `npm run start` auto-runs `prisma migrate deploy` + seeding — no shell/terminal needed for a Render/Railway deploy, just their web dashboard forms

Full guided steps for this path are being given interactively in chat, one at a time.

---

## ⚠️ महत्त्वाची तांत्रिक गोष्ट — आधी वाचा

**Backend (Node.js + PostgreSQL) Android APK मध्ये embed होऊ शकत नाही.** हे कोणत्याही technology मध्ये शक्य नाही — मोबाईल फोनवर पूर्ण database server चालवणे व्यवहार्य नाही (battery, storage, security सर्व कारणांनी). प्रत्येक real-world app (उदा. तुमचे बँकेचे app) हेच करते:

```
[Android App / APK]  ---इंटरनेटवरून HTTPS API calls--->  [Backend Server + Database]
     (frontend)                                           (कुठेतरी cloud मध्ये चालू असतो, 24x7)
```

म्हणजे तुम्हाला **backend एकदा deploy करावा लागेल** (एका cloud server वर), आणि APK त्या backend शी internet वरून बोलेल.

**मी हा chat environment मध्ये प्रत्यक्ष `.apk` file तयार करू शकत नाही** — कारण APK बनवायला Android SDK + Java + Gradle लागते, आणि हे सर्व माझ्याकडे इथे उपलब्ध नाही, आणि मला internet access पण नाही (npm packages download करणेही शक्य नाही). खाली दिलेले steps तुम्ही (किंवा कोणीही developer) **Android Studio वापरून 10-15 मिनिटांत** पूर्ण करू शकता — ते मोफत आहे आणि तुमचा स्वतःचा laptop/PC लागेल.

---

## Part 1 — Backend Deploy करणे

कोणताही Node.js + PostgreSQL support करणारा host चालेल. सोपे पर्याय:

| Service | का |
|---|---|
| **Railway.app** | सर्वात सोपे — PostgreSQL + Node दोन्ही एका click मध्ये |
| **Render.com** | Free tier उपलब्ध |
| कोणताही VPS (DigitalOcean, AWS EC2) | जास्त control, पण जास्त setup |

### Railway वर deploy (उदाहरण):

1. [railway.app](https://railway.app) वर account बनवा, "New Project" → "Deploy from GitHub repo" (आधी हा code तुमच्या GitHub वर push करा)
2. "Add PostgreSQL" plugin add करा — तो आपोआप `DATABASE_URL` environment variable देईल
3. Backend service मध्ये environment variables set करा:
   ```
   DATABASE_URL=<Railway ने दिलेला>
   JWT_SECRET=<एक लांब random string>
   NODE_ENV=production
   PORT=4000
   ```
4. Deploy झाल्यावर migration run करा (Railway च्या शell मधून):
   ```bash
   npx prisma migrate deploy
   npm run prisma:seed
   ```
5. तुम्हाला एक public URL मिळेल, उदा. `https://mandal-backend-production.up.railway.app`

हाच URL पुढच्या टप्प्यात frontend मध्ये वापरायचा आहे.

---

## Part 2 — Android APK बनवणे (Capacitor वापरून)

Frontend आधीच Capacitor साठी तयार आहे (`capacitor.config.ts` project मध्ये आहे). तुमच्या laptop वर हे steps करा:

### आवश्यक software (एकदाच install करायचे)
- [Node.js](https://nodejs.org) (v18+)
- [Android Studio](https://developer.android.com/studio) (मोफत) — यातच Android SDK + Java + Gradle सर्व येते

### Steps

```bash
cd frontend
npm install

# Backend चा खरा URL टाका (Part 1 मधून मिळालेला)
echo "VITE_API_BASE_URL=https://your-backend-url.example.com/api/v1" > .env.production

# Frontend build करा
npm run build

# Capacitor Android platform जोडा (पहिल्यांदाच)
npx cap add android

# Built frontend Android project मध्ये copy करा
npx cap sync android

# Android Studio उघडा
npx cap open android
```

Android Studio उघडल्यावर:

1. Gradle sync होईपर्यंत थांबा (पहिल्यांदा 5-10 मिनिटे लागू शकतात)
2. वरती menu मधून: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
3. Build पूर्ण झाल्यावर खालच्या कोपऱ्यात "locate" link click करा — तुमची **debug APK** इथे मिळेल:
   ```
   frontend/android/app/build/outputs/apk/debug/app-debug.apk
   ```
4. ही file फोनवर पाठवा (WhatsApp/Email/USB) आणि install करा — "Unknown sources" install ला परवानगी द्यावी लागेल (Settings → Security)

App चे नाव फोनवर **"Mandal App"** असे दिसेल (`capacitor.config.ts` मध्ये सेट केलेले).

### Production/Release APK (Play Store साठी, ऐच्छिक)

Debug APK फक्त testing साठी आहे. Play Store वर publish करायचे असल्यास signed release APK/AAB लागेल — त्यासाठी Android Studio मध्ये **Build → Generate Signed Bundle/APK** वापरा (यासाठी एक keystore बनवावी लागते).

---

## Part 3 — Local Development (backend + frontend एकत्र test करणे)

```bash
# Terminal 1 — Backend
cd backend
npm install
cp .env.example .env      # DATABASE_URL, JWT_SECRET भरा
npx prisma migrate dev
npm run prisma:seed
npm run dev                # http://localhost:4000

# Terminal 2 — Frontend
cd frontend
npm install
npm run dev                 # http://localhost:5173 (backend ला auto-proxy होतो)
```

Browser मध्ये `http://localhost:5173` उघडा.

---

## Part 4 — Project Status: काय Working आहे, काय नाही

| Module | Backend | Frontend | नोंद |
|---|:---:|:---:|---|
| Login / Auth (JWT, role-based) | ✅ | ✅ | |
| Dashboard (server-side aggregation) | ✅ | ✅ | client-side calculation करत नाही |
| Expenses (CRUD, bill photo, filters) | ✅ | ✅ | |
| Expense Categories (add/edit/deactivate) | ✅ | ✅ | Settings मध्ये |
| Donations (CRUD, auto receipt number) | ✅ | ✅ | |
| UPI Transactions (duplicate UTR check) | ✅ | ✅ | live check करताना टाईप करताच दाखवते |
| Receipt PDF | ✅ | ✅ | ⚠️ खाली बघा — font caveat |
| Members | ✅ | ✅ | basic CRUD |
| Settings — Branding (Devi photo/logo) | ✅ | ✅ | Login/Header/Receipt सर्वत्र वापरला जातो |
| i18n (मराठी/English) | — | ✅ | संपूर्ण UI मध्ये, hardcoded text नाही |
| Audit Log | ✅ (लिहितो) | ❌ | प्रत्येक बदल DB मध्ये save होतो, पण बघण्यासाठी screen अजून नाही |
| Events, Tasks, Reports | ❌ | "Coming soon" placeholder | अजून बनलेले नाहीत |
| File upload | ✅ | ✅ | bills, receipts, Devi photo, logo, member photo |
| Error handling | ✅ | ✅ | Loading/Empty/Error states प्रत्येक page वर |

⚠️ **Receipt PDF वर Marathi text:** एक free Devanagari font file manual टाकावी लागेल — `backend/assets/fonts/README.md` बघा. Font टाकेपर्यंत receipt तयार होईल पण Marathi शब्द रिकामे दिसतील (मला internet नसल्याने मी ती file आणू शकलो नाही).

---

## Part 5 — Testing झाले का? (प्रामाणिक उत्तर)

मी या sandbox मध्ये live PostgreSQL database किंवा npm install चालवू शकत नाही (internet access नाही), त्यामुळे मी संपूर्ण flow प्रत्यक्ष run करून दाखवू शकलो नाही. मी काय केले:

- **Code-level review**: प्रत्येक API endpoint, frontend service call, आणि validation schema एकमेकांशी जुळतात याची तपासणी केली (field names, types, error shapes)
- **Logic review**: duplicate UTR check, receipt number generation, balance calculation formulas manually verify केले

तुम्ही खालील flow **local मध्ये (Part 3 च्या steps ने) प्रत्यक्ष run करून test करावा**:
```
Login (चुकीचा password पण try करा) → Dashboard → Add Donation →
Add UPI Transaction (एकच UTR दोनदा टाकून duplicate error बघा) →
Receipt PDF download → Add Expense (0 किंवा negative amount टाकून validation बघा) →
Dashboard वर balance update झाले का बघा → Settings मध्ये Devi photo बदला →
Login page वर नवीन photo दिसतोय का बघा → Logout
```
काही bug सापडला तर लगेच सांगा — मी लगेच fix करेन.
