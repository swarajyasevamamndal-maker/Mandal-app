/** @type {import('tailwindcss').Config} */
export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        maroon: {
          50: "#FBF0F1",
          100: "#F3D9DC",
          400: "#A63B4A",
          500: "#8A2432",
          600: "#6E1423",
          700: "#570F1C",
          800: "#3E0A14",
          900: "#2B070E",
        },
        marigold: {
          50: "#FDF6E9",
          100: "#FAEBCB",
          300: "#EFC46A",
          400: "#E7B23A",
          500: "#C98A2B",
          600: "#A66C1F",
        },
        cream: {
          DEFAULT: "#FAF3E7",
          100: "#FFFDF9",
          200: "#F3E9D6",
        },
        ink: {
          DEFAULT: "#201319",
          800: "#2B1B22",
          700: "#38232C",
        },
      },
      fontFamily: {
        display: ["'Noto Serif Devanagari'", "'Tiro Devanagari Marathi'", "serif"],
        body: ["Inter", "'Noto Sans Devanagari'", "sans-serif"],
      },
      boxShadow: {
        card: "0 2px 10px -2px rgba(110, 20, 35, 0.12)",
        elevated: "0 8px 30px -8px rgba(110, 20, 35, 0.25)",
      },
      backgroundImage: {
        "arch-motif": "radial-gradient(circle at 50% 0%, rgba(231,178,58,0.18), transparent 60%)",
      },
    },
  },
  plugins: [],
};
