import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "org.devimandal.app",
  appName: "Mandal App",
  webDir: "dist",
  server: {
    // IMPORTANT: Capacitor bundles the built frontend into the APK, but
    // the backend (Node/Express/PostgreSQL) cannot run inside the APK —
    // mobile apps can't host a database server. The app calls your
    // deployed backend over the internet using this base URL.
    //
    // Set this to your deployed backend's HTTPS URL before running
    // `npm run build && npx cap sync android`. Since VITE_API_BASE_URL
    // is baked in at build time, androidScheme below just needs to be
    // https so Android allows the network calls.
    androidScheme: "https",
  },
};

export default config;
