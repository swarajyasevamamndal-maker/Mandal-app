# देवी मंडळ App — Frontend

## Setup

```bash
cd frontend
npm install
npm run dev     # http://localhost:5173
```

Backend आधी `http://localhost:4000` वर चालू असणे आवश्यक आहे (Vite dev server `/api` आणि `/uploads` backend कडे proxy करतो — बघा `vite.config.ts`).

## आत्तापर्यंत तयार आहे

- **Login page** — Devi photo (placeholder किंवा Settings मधून upload केलेला खरा फोटो), show/hide password, dark mode, भाषा toggle, error handling
- **Dashboard** — backend च्या `/dashboard/summary` वरून real data (client-side aggregation नाही), monthly income/expense chart, recent expenses/donations, role-based quick actions
- **Expenses** — List (search/filter/sort/pagination) → Add/Edit (category dropdown, bill photo upload, validation) → Details
- **Settings** — Mandal branding (name, devi name, contact, financial year, address), Devi photo व Logo अपलोड (लगेच login page/header वर दिसतो), Expense Categories manage (add/edit/deactivate — delete नाही)
- **Profile**, role-based navigation (sidebar desktop / bottom nav mobile), i18n (मराठी/English पूर्ण UI मध्ये), light/dark theme

## अजून backend नसलेले (frontend मध्ये "coming soon" placeholder)

Donations, UPI Transactions (backend तयार आहे, frontend pages अजून नाहीत), Members, Events, Tasks, Reports (backend अजून तयार नाही)

## Environment variables (ऐच्छिक)

`.env` file तयार करून हे override करता येते:

```
VITE_API_BASE_URL=https://your-backend.example.com/api/v1
```
