import { ReactNode } from "react";

interface StatCardProps {
  icon: ReactNode;
  label: string;
  value: string;
  tone?: "default" | "positive" | "warning";
}

const toneStyles: Record<NonNullable<StatCardProps["tone"]>, string> = {
  default: "text-maroon-700 dark:text-marigold-300",
  positive: "text-emerald-700 dark:text-emerald-400",
  warning: "text-amber-700 dark:text-amber-400",
};

export function StatCard({ icon, label, value, tone = "default" }: StatCardProps) {
  return (
    <div className="card card-gold-edge p-4 flex items-start gap-3">
      <div className="h-10 w-10 rounded-xl bg-marigold-50 dark:bg-white/5 flex items-center justify-center text-marigold-600 dark:text-marigold-300 shrink-0">
        {icon}
      </div>
      <div className="min-w-0">
        <p className="text-xs text-ink/50 dark:text-cream-100/50 truncate">{label}</p>
        <p className={`text-lg font-semibold font-display truncate ${toneStyles[tone]}`}>{value}</p>
      </div>
    </div>
  );
}
