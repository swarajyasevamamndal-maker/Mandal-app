import { AlertTriangle, Inbox, RefreshCw } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";

export function LoadingState({ label }: { label?: string }) {
  const { t } = useLanguage();
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-16 text-ink/50 dark:text-cream-100/50">
      <div className="h-8 w-8 rounded-full border-2 border-marigold-400 border-t-transparent animate-spin" />
      <p className="text-sm">{label || t.common.loading}</p>
    </div>
  );
}

export function EmptyState({ message }: { message?: string }) {
  const { t } = useLanguage();
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-16 text-ink/40 dark:text-cream-100/40">
      <Inbox size={36} strokeWidth={1.5} />
      <p className="text-sm">{message || t.common.noData}</p>
    </div>
  );
}

export function ErrorState({ message, onRetry }: { message?: string; onRetry?: () => void }) {
  const { t } = useLanguage();
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-16 text-maroon-600 dark:text-marigold-300">
      <AlertTriangle size={36} strokeWidth={1.5} />
      <p className="text-sm text-center max-w-xs">{message || t.common.error}</p>
      {onRetry && (
        <button onClick={onRetry} className="btn-secondary text-sm px-4 py-2 mt-1">
          <RefreshCw size={14} /> {t.common.retry}
        </button>
      )}
    </div>
  );
}
