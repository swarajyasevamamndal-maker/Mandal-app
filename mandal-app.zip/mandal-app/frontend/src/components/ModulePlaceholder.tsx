import { Sparkles } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";

export function ModulePlaceholder({ titleKey }: { titleKey: string }) {
  const { t } = useLanguage();
  return (
    <div className="space-y-4">
      <h1 className="text-xl font-display font-semibold text-maroon-700 dark:text-marigold-300">
        {titleKey}
      </h1>
      <div className="card p-10 flex flex-col items-center text-center gap-3 text-ink/50 dark:text-cream-100/50">
        <Sparkles size={32} strokeWidth={1.5} className="text-marigold-400" />
        <p className="text-sm">{t.common.comingSoon}</p>
      </div>
    </div>
  );
}
