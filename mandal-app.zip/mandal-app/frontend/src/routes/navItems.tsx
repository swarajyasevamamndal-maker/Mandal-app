import {
  Banknote,
  Calendar,
  Gauge,
  HandCoins,
  ListChecks,
  QrCode,
  Settings,
  UsersRound,
  FileBarChart,
} from "lucide-react";
import { Role } from "../types";

export interface NavItem {
  to: string;
  labelKey: "dashboard" | "expenses" | "donations" | "upi" | "members" | "events" | "tasks" | "reports" | "settings";
  icon: typeof Gauge;
  roles?: Role[]; // undefined = all roles
}

export const navItems: NavItem[] = [
  { to: "/dashboard", labelKey: "dashboard", icon: Gauge },
  { to: "/expenses", labelKey: "expenses", icon: Banknote, roles: ["ADMIN", "TREASURER"] },
  { to: "/donations", labelKey: "donations", icon: HandCoins, roles: ["ADMIN", "TREASURER"] },
  { to: "/upi", labelKey: "upi", icon: QrCode, roles: ["ADMIN", "TREASURER"] },
  { to: "/members", labelKey: "members", icon: UsersRound, roles: ["ADMIN"] },
  { to: "/events", labelKey: "events", icon: Calendar },
  { to: "/tasks", labelKey: "tasks", icon: ListChecks },
  { to: "/reports", labelKey: "reports", icon: FileBarChart },
  { to: "/settings", labelKey: "settings", icon: Settings, roles: ["ADMIN"] },
];

export function visibleNavItems(role: Role) {
  return navItems.filter((item) => !item.roles || item.roles.includes(role));
}

// A shorter set for the mobile bottom bar (5 max is the comfortable limit).
export const mobilePrimaryKeys: NavItem["labelKey"][] = [
  "dashboard",
  "expenses",
  "donations",
  "reports",
];
