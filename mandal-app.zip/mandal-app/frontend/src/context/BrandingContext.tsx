import { createContext, ReactNode, useCallback, useContext, useEffect, useState } from "react";
import deviPlaceholder from "../assets/devi-placeholder.svg";
import { fetchPublicBranding, PublicBranding } from "../services/api/settings";

interface BrandingContextValue {
  mandalName: string;
  deviName: string;
  deviPhotoUrl: string; // always resolved — falls back to placeholder
  logoUrl: string | null;
  isPlaceholderPhoto: boolean;
  refresh: () => void;
}

const DEFAULTS: PublicBranding = { mandalName: "देवी मंडळ", deviName: "श्री देवी", logoUrl: null, deviPhotoUrl: null };

const BrandingContext = createContext<BrandingContextValue | null>(null);

export function BrandingProvider({ children }: { children: ReactNode }) {
  const [branding, setBranding] = useState<PublicBranding>(DEFAULTS);

  const refresh = useCallback(() => {
    fetchPublicBranding()
      .then(setBranding)
      .catch(() => setBranding(DEFAULTS)); // Login page must never break if this call fails
  }, []);

  useEffect(refresh, [refresh]);

  const value: BrandingContextValue = {
    mandalName: branding.mandalName || DEFAULTS.mandalName,
    deviName: branding.deviName || DEFAULTS.deviName,
    deviPhotoUrl: branding.deviPhotoUrl || deviPlaceholder,
    logoUrl: branding.logoUrl || null,
    isPlaceholderPhoto: !branding.deviPhotoUrl,
    refresh,
  };

  return <BrandingContext.Provider value={value}>{children}</BrandingContext.Provider>;
}

export function useBranding() {
  const ctx = useContext(BrandingContext);
  if (!ctx) throw new Error("useBranding must be used within BrandingProvider");
  return ctx;
}
