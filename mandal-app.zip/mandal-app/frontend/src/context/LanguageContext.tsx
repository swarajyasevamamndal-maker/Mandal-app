import { createContext, ReactNode, useContext, useMemo, useState } from "react";
import { en } from "../i18n/en";
import { mr } from "../i18n/mr";

type Language = "mr" | "en";

interface LanguageContextValue {
  language: Language;
  toggleLanguage: () => void;
  t: typeof mr;
}

const LanguageContext = createContext<LanguageContextValue | null>(null);

const STORAGE_KEY = "mandal_language";

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>(
    () => (localStorage.getItem(STORAGE_KEY) as Language) || "mr"
  );

  const value = useMemo<LanguageContextValue>(
    () => ({
      language,
      toggleLanguage: () =>
        setLanguage((prev) => {
          const next = prev === "mr" ? "en" : "mr";
          localStorage.setItem(STORAGE_KEY, next);
          return next;
        }),
      t: language === "mr" ? mr : en,
    }),
    [language]
  );

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLanguage must be used within LanguageProvider");
  return ctx;
}
