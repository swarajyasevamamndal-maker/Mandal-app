import { Eye, EyeOff, Moon, Sun } from "lucide-react";
import { FormEvent, useState } from "react";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useBranding } from "../context/BrandingContext";
import { useLanguage } from "../context/LanguageContext";
import { useTheme } from "../context/ThemeContext";
import { apiErrorMessage } from "../services/api/client";
import { useToast } from "../context/ToastContext";

export default function Login() {
  const { user, login } = useAuth();
  const { t, language, toggleLanguage } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const { showToast } = useToast();
  const { mandalName, deviPhotoUrl } = useBranding();
  const navigate = useNavigate();
  const location = useLocation();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (user) {
    const redirectTo = (location.state as { from?: string })?.from || "/dashboard";
    return <Navigate to={redirectTo} replace />;
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (!email.trim() || !password) {
      setError(t.login.required);
      return;
    }

    setIsSubmitting(true);
    try {
      await login(email.trim(), password);
      navigate("/dashboard", { replace: true });
    } catch (err) {
      setError(apiErrorMessage(err, t.login.invalidCredentials));
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen bg-cream dark:bg-ink bg-arch-motif flex flex-col items-center justify-center px-4 py-10 relative">
      <div className="absolute top-4 right-4 flex gap-2">
        <button
          onClick={toggleLanguage}
          className="h-9 px-3 rounded-full bg-white/70 dark:bg-white/10 text-xs font-medium text-maroon-700 dark:text-marigold-300 shadow-card"
          aria-label="Toggle language"
        >
          {language === "mr" ? "EN" : "मर"}
        </button>
        <button
          onClick={toggleTheme}
          className="h-9 w-9 rounded-full bg-white/70 dark:bg-white/10 flex items-center justify-center text-maroon-700 dark:text-marigold-300 shadow-card"
          aria-label="Toggle dark mode"
        >
          {theme === "light" ? <Moon size={16} /> : <Sun size={16} />}
        </button>
      </div>

      <div className="w-full max-w-sm animate-[fadeIn_0.4s_ease-out]">
        <div className="flex flex-col items-center text-center mb-6">
          <div className="rounded-full p-1.5 bg-gradient-to-br from-marigold-400 to-maroon-600 shadow-elevated">
            <img
              src={deviPhotoUrl}
              alt={mandalName}
              className="h-32 w-32 rounded-full object-cover bg-cream-100 border-4 border-cream-100 dark:border-ink-800"
            />
          </div>
          <h1 className="mt-5 text-2xl font-bold text-maroon-700 dark:text-marigold-300">
            {mandalName}
          </h1>
          <p className="text-sm text-ink/60 dark:text-cream-100/60 mt-1">{t.appSubtitle}</p>
        </div>

        <form onSubmit={handleSubmit} className="card card-gold-edge p-6 space-y-4">
          <div>
            <label htmlFor="email" className="label-text">
              {t.login.identifierLabel}
            </label>
            <input
              id="email"
              type="text"
              autoComplete="username"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="input-field"
              placeholder="you@mandal.org"
            />
          </div>

          <div>
            <label htmlFor="password" className="label-text">
              {t.login.passwordLabel}
            </label>
            <div className="relative">
              <input
                id="password"
                type={showPassword ? "text" : "password"}
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="input-field pr-12"
                placeholder="••••••••"
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-ink/40 dark:text-cream-100/40 hover:text-maroon-600"
                aria-label={showPassword ? t.login.hide : t.login.show}
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          {error && (
            <p role="alert" className="text-sm text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-500/10 rounded-lg px-3 py-2">
              {error}
            </p>
          )}

          <button type="submit" disabled={isSubmitting} className="btn-primary w-full">
            {isSubmitting ? (
              <span className="h-4 w-4 rounded-full border-2 border-white/40 border-t-white animate-spin" />
            ) : null}
            {t.login.loginButton}
          </button>

          <button
            type="button"
            onClick={() =>
              showToast(
                language === "mr"
                  ? "कृपया Admin शी संपर्क साधा"
                  : "Please contact your Admin",
                "error"
              )
            }
            className="w-full text-center text-sm text-maroon-600 dark:text-marigold-300 hover:underline"
          >
            {t.login.forgotPassword}
          </button>
        </form>
      </div>
    </div>
  );
}
