import { ArrowLeft } from "lucide-react";
import { FormEvent, useState } from "react";
import { useNavigate } from "react-router-dom";
import { FormField } from "../../components/FormField";
import { useLanguage } from "../../context/LanguageContext";
import { useToast } from "../../context/ToastContext";
import { apiErrorMessage } from "../../services/api/client";
import { createDonation } from "../../services/api/donations";

const paymentMethods = [
  { value: "CASH", labelMr: "रोख", labelEn: "Cash" },
  { value: "UPI", labelMr: "UPI", labelEn: "UPI" },
  { value: "BANK_TRANSFER", labelMr: "Bank Transfer", labelEn: "Bank Transfer" },
  { value: "OTHER", labelMr: "इतर", labelEn: "Other" },
];

export default function AddDonation() {
  const { t, language } = useLanguage();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [form, setForm] = useState({
    date: new Date().toISOString().slice(0, 10),
    donorName: "",
    donorMobile: "",
    amount: "",
    paymentMethod: "CASH",
    upiTxnRefId: "",
    purpose: "",
    notes: "",
  });

  function validate(): boolean {
    const next: Record<string, string> = {};
    const req = language === "mr" ? "ही माहिती आवश्यक आहे" : "This field is required";

    if (!form.date) next.date = req;
    if (!form.donorName.trim()) next.donorName = req;
    if (form.donorMobile && !/^[0-9]{10}$/.test(form.donorMobile)) {
      next.donorMobile = language === "mr" ? "Mobile number 10 अंकी असावा" : "Mobile number must be 10 digits";
    }
    const amountNum = Number(form.amount);
    if (!form.amount || Number.isNaN(amountNum) || amountNum <= 0) {
      next.amount = language === "mr" ? "योग्य रक्कम टाका (0 पेक्षा जास्त)" : "Enter a valid amount greater than 0";
    }

    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    try {
      await createDonation({
        date: form.date,
        donorName: form.donorName,
        donorMobile: form.donorMobile || undefined,
        amount: Number(form.amount),
        paymentMethod: form.paymentMethod,
        upiTxnRefId: form.upiTxnRefId || undefined,
        purpose: form.purpose || undefined,
        notes: form.notes || undefined,
      });
      showToast(language === "mr" ? "Donation जोडली, receipt तयार झाली" : "Donation added, receipt generated");
      navigate("/donations");
    } catch (err) {
      showToast(apiErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="max-w-xl mx-auto space-y-4">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1.5 text-sm text-ink/60 dark:text-cream-100/60">
        <ArrowLeft size={16} /> {language === "mr" ? "मागे" : "Back"}
      </button>

      <h1 className="text-xl font-display font-semibold text-maroon-700 dark:text-marigold-300">
        {t.dashboard.addDonation}
      </h1>

      <form onSubmit={handleSubmit} className="card card-gold-edge p-5 space-y-4">
        <FormField label={language === "mr" ? "तारीख" : "Date"} htmlFor="date" required error={errors.date}>
          <input id="date" type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className="input-field" />
        </FormField>

        <FormField label={language === "mr" ? "Donor नाव" : "Donor Name"} htmlFor="donorName" required error={errors.donorName}>
          <input id="donorName" value={form.donorName} onChange={(e) => setForm({ ...form, donorName: e.target.value })} className="input-field" />
        </FormField>

        <FormField label={language === "mr" ? "Mobile Number" : "Mobile Number"} htmlFor="donorMobile" error={errors.donorMobile}>
          <input id="donorMobile" value={form.donorMobile} onChange={(e) => setForm({ ...form, donorMobile: e.target.value })} className="input-field" placeholder="9876543210" />
        </FormField>

        <FormField label={language === "mr" ? "रक्कम (₹)" : "Amount (₹)"} htmlFor="amount" required error={errors.amount}>
          <input id="amount" type="number" min="0" step="0.01" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} className="input-field" placeholder="0" />
        </FormField>

        <FormField label="Payment Method" htmlFor="paymentMethod" required>
          <select id="paymentMethod" value={form.paymentMethod} onChange={(e) => setForm({ ...form, paymentMethod: e.target.value })} className="input-field">
            {paymentMethods.map((m) => (
              <option key={m.value} value={m.value}>{language === "mr" ? m.labelMr : m.labelEn}</option>
            ))}
          </select>
        </FormField>

        {form.paymentMethod === "UPI" && (
          <FormField label="UPI Transaction ID / UTR" htmlFor="upiTxnRefId">
            <input id="upiTxnRefId" value={form.upiTxnRefId} onChange={(e) => setForm({ ...form, upiTxnRefId: e.target.value })} className="input-field" />
          </FormField>
        )}

        <FormField label={language === "mr" ? "उद्देश" : "Purpose"} htmlFor="purpose">
          <input id="purpose" value={form.purpose} onChange={(e) => setForm({ ...form, purpose: e.target.value })} className="input-field" placeholder={language === "mr" ? "उदा. देवी स्थापना" : "e.g. Devi Sthapana"} />
        </FormField>

        <FormField label={language === "mr" ? "टीप" : "Notes"} htmlFor="notes">
          <textarea id="notes" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="input-field" rows={2} />
        </FormField>

        <p className="text-xs text-ink/40 dark:text-cream-100/40">
          {language === "mr" ? "Receipt क्रमांक आपोआप generate होईल." : "Receipt number will be generated automatically."}
        </p>

        <div className="flex gap-3 pt-2">
          <button type="submit" disabled={isSubmitting} className="btn-primary flex-1">{isSubmitting ? "..." : t.common.save}</button>
          <button type="button" onClick={() => navigate(-1)} className="btn-secondary flex-1">{t.common.cancel}</button>
        </div>
      </form>
    </div>
  );
}
