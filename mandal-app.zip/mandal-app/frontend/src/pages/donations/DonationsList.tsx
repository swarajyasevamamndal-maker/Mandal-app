import { Download, Plus, Search } from "lucide-react";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { EmptyState, ErrorState, LoadingState } from "../../components/StateViews";
import { useAuth } from "../../context/AuthContext";
import { useLanguage } from "../../context/LanguageContext";
import { useToast } from "../../context/ToastContext";
import { apiErrorMessage } from "../../services/api/client";
import { downloadReceipt, listDonations } from "../../services/api/donations";
import { Donation, PaginatedResponse } from "../../types";
import { formatDate, formatInr } from "../../utils/format";

const PAGE_SIZE = 15;

export default function DonationsList() {
  const { t, language } = useLanguage();
  const { hasRole } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const [result, setResult] = useState<PaginatedResponse<Donation> | null>(null);
  const [status, setStatus] = useState<"loading" | "error" | "ready">("loading");
  const [errorMsg, setErrorMsg] = useState<string>();
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);

  function load() {
    setStatus("loading");
    listDonations({ page, pageSize: PAGE_SIZE, search: search || undefined, sortBy: "date", sortOrder: "desc" })
      .then((data) => {
        setResult(data);
        setStatus("ready");
      })
      .catch((err) => {
        setErrorMsg(apiErrorMessage(err));
        setStatus("error");
      });
  }

  useEffect(load, [page]);

  function handleSearchSubmit(e: React.FormEvent) {
    e.preventDefault();
    setPage(1);
    load();
  }

  async function handleDownload(d: Donation, e: React.MouseEvent) {
    e.stopPropagation();
    setDownloadingId(d.id);
    try {
      await downloadReceipt(d.id, d.receiptNumber);
    } catch (err) {
      showToast(apiErrorMessage(err), "error");
    } finally {
      setDownloadingId(null);
    }
  }

  const canManage = hasRole("ADMIN", "TREASURER");

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h1 className="text-xl font-display font-semibold text-maroon-700 dark:text-marigold-300">
          {t.nav.donations}
        </h1>
        {canManage && (
          <button onClick={() => navigate("/donations/new")} className="btn-primary text-sm px-4 py-2.5">
            <Plus size={16} /> {t.dashboard.addDonation}
          </button>
        )}
      </div>

      <form onSubmit={handleSearchSubmit} className="card p-3 relative">
        <Search size={16} className="absolute left-6 top-1/2 -translate-y-1/2 text-ink/40" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={language === "mr" ? "Donor नाव / Receipt क्रमांक शोधा..." : "Search donor / receipt number..."}
          className="input-field pl-9"
        />
      </form>

      {status === "loading" && <LoadingState />}
      {status === "error" && <ErrorState message={errorMsg} onRetry={load} />}
      {status === "ready" && result && result.items.length === 0 && <EmptyState />}

      {status === "ready" && result && result.items.length > 0 && (
        <div className="card divide-y divide-marigold-100/60 dark:divide-white/5">
          {result.items.map((d) => (
            <div
              key={d.id}
              onClick={() => navigate(`/donations/${d.id}`)}
              className="flex items-center justify-between gap-3 px-4 py-3 cursor-pointer hover:bg-marigold-50 dark:hover:bg-white/5 transition"
            >
              <div className="min-w-0">
                <p className="font-medium truncate">{d.donorName}</p>
                <p className="text-xs text-ink/50 dark:text-cream-100/50">
                  {d.receiptNumber} · {formatDate(d.date)} · {d.paymentMethod.replace("_", " ")}
                </p>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <span className="font-semibold text-emerald-700 dark:text-emerald-400">{formatInr(d.amount)}</span>
                <button
                  onClick={(e) => handleDownload(d, e)}
                  disabled={downloadingId === d.id}
                  className="text-ink/30 hover:text-maroon-600 p-1"
                  aria-label="Download receipt"
                >
                  <Download size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {status === "ready" && result && result.total > PAGE_SIZE && (
        <div className="flex items-center justify-center gap-3 text-sm">
          <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="btn-secondary px-3 py-1.5 disabled:opacity-40">←</button>
          <span className="text-ink/60 dark:text-cream-100/60">{page} / {Math.ceil(result.total / PAGE_SIZE)}</span>
          <button disabled={page >= Math.ceil(result.total / PAGE_SIZE)} onClick={() => setPage((p) => p + 1)} className="btn-secondary px-3 py-1.5 disabled:opacity-40">→</button>
        </div>
      )}
    </div>
  );
}
