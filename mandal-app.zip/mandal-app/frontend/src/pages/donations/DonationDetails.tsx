import { ArrowLeft, Download } from "lucide-react";
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ErrorState, LoadingState } from "../../components/StateViews";
import { useLanguage } from "../../context/LanguageContext";
import { useToast } from "../../context/ToastContext";
import { apiErrorMessage } from "../../services/api/client";
import { downloadReceipt, getDonation } from "../../services/api/donations";
import { Donation } from "../../types";
import { formatDate, formatInr } from "../../utils/format";

export default function DonationDetails() {
  const { id } = useParams();
  const { language } = useLanguage();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const [donation, setDonation] = useState<Donation | null>(null);
  const [status, setStatus] = useState<"loading" | "error" | "ready">("loading");
  const [errorMsg, setErrorMsg] = useState<string>();
  const [downloading, setDownloading] = useState(false);

  function load() {
    if (!id) return;
    setStatus("loading");
    getDonation(id)
      .then((d) => {
        setDonation(d);
        setStatus("ready");
      })
      .catch((err) => {
        setErrorMsg(apiErrorMessage(err));
        setStatus("error");
      });
  }

  useEffect(load, [id]);

  async function handleDownload() {
    if (!donation) return;
    setDownloading(true);
    try {
      await downloadReceipt(donation.id, donation.receiptNumber);
    } catch (err) {
      showToast(apiErrorMessage(err), "error");
    } finally {
      setDownloading(false);
    }
  }

  if (status === "loading") return <LoadingState />;
  if (status === "error") return <ErrorState message={errorMsg} onRetry={load} />;
  if (!donation) return null;

  const rows: [string, string][] = [
    [language === "mr" ? "Receipt क्रमांक" : "Receipt No.", donation.receiptNumber],
    [language === "mr" ? "तारीख" : "Date", formatDate(donation.date)],
    [language === "mr" ? "Payment Method" : "Payment Method", donation.paymentMethod.replace("_", " ")],
    ...(donation.donorMobile ? ([[language === "mr" ? "Mobile" : "Mobile", donation.donorMobile]] as [string, string][]) : []),
    ...(donation.upiTxnRefId ? ([["UTR / Txn ID", donation.upiTxnRefId]] as [string, string][]) : []),
    ...(donation.purpose ? ([[language === "mr" ? "उद्देश" : "Purpose", donation.purpose]] as [string, string][]) : []),
  ];

  return (
    <div className="max-w-xl mx-auto space-y-4">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1.5 text-sm text-ink/60 dark:text-cream-100/60">
        <ArrowLeft size={16} /> {language === "mr" ? "मागे" : "Back"}
      </button>

      <div className="card card-gold-edge p-5">
        <p className="text-sm text-ink/50 dark:text-cream-100/50 mb-1">{donation.donorName}</p>
        <p className="text-3xl font-display font-bold text-emerald-700 dark:text-emerald-400 mb-5">
          {formatInr(donation.amount)}
        </p>

        <dl className="divide-y divide-marigold-100/60 dark:divide-white/5">
          {rows.map(([label, value]) => (
            <div key={label} className="flex justify-between py-2.5 text-sm">
              <dt className="text-ink/50 dark:text-cream-100/50">{label}</dt>
              <dd className="font-medium text-right">{value}</dd>
            </div>
          ))}
        </dl>

        {donation.notes && (
          <p className="mt-4 text-sm text-ink/60 dark:text-cream-100/60 bg-marigold-50 dark:bg-white/5 rounded-lg p-3">
            {donation.notes}
          </p>
        )}

        <button onClick={handleDownload} disabled={downloading} className="btn-primary w-full mt-5">
          <Download size={16} /> {downloading ? "..." : language === "mr" ? "Receipt PDF Download करा" : "Download Receipt PDF"}
        </button>
      </div>
    </div>
  );
}
