import { ArrowLeft, Upload } from "lucide-react";
import { FormEvent, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { FormField } from "../../components/FormField";
import { LoadingState } from "../../components/StateViews";
import { useLanguage } from "../../context/LanguageContext";
import { useToast } from "../../context/ToastContext";
import { Category, listCategories } from "../../services/api/categories";
import { apiErrorMessage } from "../../services/api/client";
import { createExpense, getExpense, updateExpense } from "../../services/api/expenses";

const paymentMethods = [
  { value: "CASH", labelMr: "रोख", labelEn: "Cash" },
  { value: "UPI", labelMr: "UPI", labelEn: "UPI" },
  { value: "BANK_TRANSFER", labelMr: "Bank Transfer", labelEn: "Bank Transfer" },
  { value: "OTHER", labelMr: "इतर", labelEn: "Other" },
];

export default function AddExpense() {
  const { t, language } = useLanguage();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = !!id;

  const [categories, setCategories] = useState<Category[]>([]);
  const [loadingExisting, setLoadingExisting] = useState(isEdit);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [billPhoto, setBillPhoto] = useState<File | null>(null);

  const [form, setForm] = useState({
    date: new Date().toISOString().slice(0, 10),
    categoryId: "",
    description: "",
    amount: "",
    paymentMethod: "CASH",
    vendorName: "",
    billNumber: "",
    notes: "",
  });

  useEffect(() => {
    // includeInactive so an expense whose category was later deactivated
    // still shows correctly when editing (avoids silently losing/
    // corrupting the categoryId on save).
    listCategories(true).then(setCategories).catch(() => {});
  }, []);

  useEffect(() => {
    if (!id) return;
    getExpense(id)
      .then((expense) => {
        setForm({
          date: expense.date.slice(0, 10),
          categoryId: expense.categoryId,
          description: expense.description,
          amount: String(expense.amount),
          paymentMethod: expense.paymentMethod,
          vendorName: expense.vendorName || "",
          billNumber: expense.billNumber || "",
          notes: expense.notes || "",
        });
      })
      .catch((err) => showToast(apiErrorMessage(err), "error"))
      .finally(() => setLoadingExisting(false));
  }, [id]);

  function validate(): boolean {
    const next: Record<string, string> = {};
    const req = language === "mr" ? "ही माहिती आवश्यक आहे" : "This field is required";

    if (!form.date) next.date = req;
    if (!form.categoryId) next.categoryId = req;
    if (!form.description.trim()) next.description = req;
    const amountNum = Number(form.amount);
    if (!form.amount || Number.isNaN(amountNum) || amountNum <= 0) {
      next.amount = language === "mr" ? "योग्य रक्कम टाका (0 पेक्षा जास्त)" : "Enter a valid amount greater than 0";
    }

    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    try {
      const formData = new FormData();
      formData.append("date", form.date);
      formData.append("categoryId", form.categoryId);
      formData.append("description", form.description);
      formData.append("amount", form.amount);
      formData.append("paymentMethod", form.paymentMethod);
      if (form.vendorName) formData.append("vendorName", form.vendorName);
      if (form.billNumber) formData.append("billNumber", form.billNumber);
      if (form.notes) formData.append("notes", form.notes);
      if (billPhoto) formData.append("billPhoto", billPhoto);

      if (isEdit && id) {
        await updateExpense(id, formData);
        showToast(language === "mr" ? "Expense update केला" : "Expense updated");
      } else {
        await createExpense(formData);
        showToast(language === "mr" ? "Expense जोडला" : "Expense added");
      }
      navigate("/expenses");
    } catch (err) {
      showToast(apiErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  if (loadingExisting) return <LoadingState />;

  return (
    <div className="max-w-xl mx-auto space-y-4">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1.5 text-sm text-ink/60 dark:text-cream-100/60">
        <ArrowLeft size={16} /> {language === "mr" ? "मागे" : "Back"}
      </button>

      <h1 className="text-xl font-display font-semibold text-maroon-700 dark:text-marigold-300">
        {isEdit ? t.nav.expenses + " " + (language === "mr" ? "संपादित करा" : "Edit") : t.dashboard.addExpense}
      </h1>

      <form onSubmit={handleSubmit} className="card card-gold-edge p-5 space-y-4">
        <FormField label={language === "mr" ? "तारीख" : "Date"} htmlFor="date" required error={errors.date}>
          <input
            id="date"
            type="date"
            value={form.date}
            onChange={(e) => setForm({ ...form, date: e.target.value })}
            className="input-field"
          />
        </FormField>

        <FormField label={language === "mr" ? "Category" : "Category"} htmlFor="category" required error={errors.categoryId}>
          <select
            id="category"
            value={form.categoryId}
            onChange={(e) => setForm({ ...form, categoryId: e.target.value })}
            className="input-field"
          >
            <option value="">{language === "mr" ? "निवडा" : "Select"}</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {language === "mr" ? c.nameMr : c.nameEn}
              </option>
            ))}
          </select>
        </FormField>

        <FormField label={language === "mr" ? "वर्णन" : "Description"} htmlFor="description" required error={errors.description}>
          <input
            id="description"
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            className="input-field"
            placeholder={language === "mr" ? "उदा. फुले - आरती साठी" : "e.g. Flowers for aarti"}
          />
        </FormField>

        <FormField label={language === "mr" ? "रक्कम (₹)" : "Amount (₹)"} htmlFor="amount" required error={errors.amount}>
          <input
            id="amount"
            type="number"
            min="0"
            step="0.01"
            value={form.amount}
            onChange={(e) => setForm({ ...form, amount: e.target.value })}
            className="input-field"
            placeholder="0"
          />
        </FormField>

        <FormField label={language === "mr" ? "Payment Method" : "Payment Method"} htmlFor="paymentMethod" required>
          <select
            id="paymentMethod"
            value={form.paymentMethod}
            onChange={(e) => setForm({ ...form, paymentMethod: e.target.value })}
            className="input-field"
          >
            {paymentMethods.map((m) => (
              <option key={m.value} value={m.value}>
                {language === "mr" ? m.labelMr : m.labelEn}
              </option>
            ))}
          </select>
        </FormField>

        <div className="grid grid-cols-2 gap-3">
          <FormField label={language === "mr" ? "दुकान/Vendor" : "Vendor"} htmlFor="vendorName">
            <input
              id="vendorName"
              value={form.vendorName}
              onChange={(e) => setForm({ ...form, vendorName: e.target.value })}
              className="input-field"
            />
          </FormField>
          <FormField label={language === "mr" ? "Bill क्रमांक" : "Bill Number"} htmlFor="billNumber">
            <input
              id="billNumber"
              value={form.billNumber}
              onChange={(e) => setForm({ ...form, billNumber: e.target.value })}
              className="input-field"
            />
          </FormField>
        </div>

        <FormField label={language === "mr" ? "Bill / Receipt फोटो" : "Bill / Receipt Photo"} htmlFor="billPhoto">
          <label className="flex items-center gap-2 justify-center border-2 border-dashed border-marigold-200 dark:border-white/10 rounded-xl px-4 py-4 cursor-pointer text-sm text-ink/50 dark:text-cream-100/50 hover:border-marigold-400">
            <Upload size={16} />
            {billPhoto ? billPhoto.name : language === "mr" ? "फोटो निवडा" : "Choose photo"}
            <input
              id="billPhoto"
              type="file"
              accept="image/*,.pdf"
              className="hidden"
              onChange={(e) => setBillPhoto(e.target.files?.[0] || null)}
            />
          </label>
        </FormField>

        <FormField label={language === "mr" ? "टीप" : "Notes"} htmlFor="notes">
          <textarea
            id="notes"
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
            className="input-field"
            rows={2}
          />
        </FormField>

        <div className="flex gap-3 pt-2">
          <button type="submit" disabled={isSubmitting} className="btn-primary flex-1">
            {isSubmitting ? "..." : t.common.save}
          </button>
          <button type="button" onClick={() => navigate(-1)} className="btn-secondary flex-1">
            {t.common.cancel}
          </button>
        </div>
      </form>
    </div>
  );
}
