import { ArrowLeft, Pencil } from "lucide-react";
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ErrorState, LoadingState } from "../../components/StateViews";
import { useAuth } from "../../context/AuthContext";
import { useLanguage } from "../../context/LanguageContext";
import { apiErrorMessage } from "../../services/api/client";
import { getExpense } from "../../services/api/expenses";
import { Expense } from "../../types";
import { formatDate, formatInr } from "../../utils/format";

export default function ExpenseDetails() {
  const { id } = useParams();
  const { language } = useLanguage();
  const { hasRole } = useAuth();
  const navigate = useNavigate();

  const [expense, setExpense] = useState<Expense | null>(null);
  const [status, setStatus] = useState<"loading" | "error" | "ready">("loading");
  const [errorMsg, setErrorMsg] = useState<string>();

  function load() {
    if (!id) return;
    setStatus("loading");
    getExpense(id)
      .then((e) => {
        setExpense(e);
        setStatus("ready");
      })
      .catch((err) => {
        setErrorMsg(apiErrorMessage(err));
        setStatus("error");
      });
  }

  useEffect(load, [id]);

  if (status === "loading") return <LoadingState />;
  if (status === "error") return <ErrorState message={errorMsg} onRetry={load} />;
  if (!expense) return null;

  const rows: [string, string][] = [
    [language === "mr" ? "तारीख" : "Date", formatDate(expense.date)],
    [language === "mr" ? "Category" : "Category", language === "mr" ? expense.category.nameMr : expense.category.nameEn],
    [language === "mr" ? "Payment Method" : "Payment Method", expense.paymentMethod.replace("_", " ")],
    ...(expense.vendorName ? ([[language === "mr" ? "दुकान" : "Vendor", expense.vendorName]] as [string, string][]) : []),
    ...(expense.billNumber ? ([[language === "mr" ? "Bill क्रमांक" : "Bill Number", expense.billNumber]] as [string, string][]) : []),
    ...(expense.paidBy ? ([[language === "mr" ? "कोणी दिले" : "Paid By", expense.paidBy.name]] as [string, string][]) : []),
  ];

  return (
    <div className="max-w-xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <button onClick={() => navigate(-1)} className="flex items-center gap-1.5 text-sm text-ink/60 dark:text-cream-100/60">
          <ArrowLeft size={16} /> {language === "mr" ? "मागे" : "Back"}
        </button>
        {hasRole("ADMIN", "TREASURER") && (
          <button onClick={() => navigate(`/expenses/${expense.id}/edit`)} className="btn-secondary text-sm px-3 py-1.5">
            <Pencil size={14} /> {language === "mr" ? "संपादित करा" : "Edit"}
          </button>
        )}
      </div>

      <div className="card card-gold-edge p-5">
        <p className="text-sm text-ink/50 dark:text-cream-100/50 mb-1">{expense.description}</p>
        <p className="text-3xl font-display font-bold text-maroon-700 dark:text-marigold-300 mb-5">
          {formatInr(expense.amount)}
        </p>

        <dl className="divide-y divide-marigold-100/60 dark:divide-white/5">
          {rows.map(([label, value]) => (
            <div key={label} className="flex justify-between py-2.5 text-sm">
              <dt className="text-ink/50 dark:text-cream-100/50">{label}</dt>
              <dd className="font-medium text-right">{value}</dd>
            </div>
          ))}
        </dl>

        {expense.notes && (
          <p className="mt-4 text-sm text-ink/60 dark:text-cream-100/60 bg-marigold-50 dark:bg-white/5 rounded-lg p-3">
            {expense.notes}
          </p>
        )}

        {expense.billPhotoUrl && (
          <a href={expense.billPhotoUrl} target="_blank" rel="noreferrer" className="block mt-4">
            <img src={expense.billPhotoUrl} alt="Bill" className="rounded-xl border border-marigold-100/60 dark:border-white/10 max-h-64 object-cover w-full" />
          </a>
        )}
      </div>
    </div>
  );
}
