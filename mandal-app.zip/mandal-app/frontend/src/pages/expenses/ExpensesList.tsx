import { Plus, Search, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { EmptyState, ErrorState, LoadingState } from "../../components/StateViews";
import { useAuth } from "../../context/AuthContext";
import { useLanguage } from "../../context/LanguageContext";
import { useToast } from "../../context/ToastContext";
import { Category, listCategories } from "../../services/api/categories";
import { apiErrorMessage } from "../../services/api/client";
import { deleteExpense, listExpenses } from "../../services/api/expenses";
import { Expense, PaginatedResponse } from "../../types";
import { formatDate, formatInr } from "../../utils/format";

const PAGE_SIZE = 15;

export default function ExpensesList() {
  const { t, language } = useLanguage();
  const { hasRole } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const [result, setResult] = useState<PaginatedResponse<Expense> | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [status, setStatus] = useState<"loading" | "error" | "ready">("loading");
  const [errorMsg, setErrorMsg] = useState<string>();

  const [search, setSearch] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("");
  const [page, setPage] = useState(1);

  useEffect(() => {
    listCategories().then(setCategories).catch(() => {});
  }, []);

  function load() {
    setStatus("loading");
    listExpenses({
      page,
      pageSize: PAGE_SIZE,
      search: search || undefined,
      categoryId: categoryId || undefined,
      paymentMethod: paymentMethod || undefined,
      sortBy: "date",
      sortOrder: "desc",
    })
      .then((data) => {
        setResult(data);
        setStatus("ready");
      })
      .catch((err) => {
        setErrorMsg(apiErrorMessage(err));
        setStatus("error");
      });
  }

  useEffect(load, [page, categoryId, paymentMethod]);

  function handleSearchSubmit(e: React.FormEvent) {
    e.preventDefault();
    setPage(1);
    load();
  }

  async function handleDelete(id: string) {
    if (!window.confirm(language === "mr" ? "हा खर्च delete करायचा आहे का?" : "Delete this expense?")) return;
    try {
      await deleteExpense(id);
      showToast(language === "mr" ? "Expense delete केला" : "Expense deleted");
      load();
    } catch (err) {
      showToast(apiErrorMessage(err), "error");
    }
  }

  const canManage = hasRole("ADMIN", "TREASURER");

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h1 className="text-xl font-display font-semibold text-maroon-700 dark:text-marigold-300">
          {t.nav.expenses}
        </h1>
        {canManage && (
          <button onClick={() => navigate("/expenses/new")} className="btn-primary text-sm px-4 py-2.5">
            <Plus size={16} /> {t.dashboard.addExpense}
          </button>
        )}
      </div>

      <div className="card p-3 space-y-3">
        <form onSubmit={handleSearchSubmit} className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink/40" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t.common.search}
            className="input-field pl-9"
          />
        </form>
        <div className="flex gap-2 flex-wrap">
          <select
            value={categoryId}
            onChange={(e) => {
              setCategoryId(e.target.value);
              setPage(1);
            }}
            className="input-field w-auto text-sm py-2"
          >
            <option value="">{language === "mr" ? "सर्व Categories" : "All Categories"}</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {language === "mr" ? c.nameMr : c.nameEn}
              </option>
            ))}
          </select>
          <select
            value={paymentMethod}
            onChange={(e) => {
              setPaymentMethod(e.target.value);
              setPage(1);
            }}
            className="input-field w-auto text-sm py-2"
          >
            <option value="">{language === "mr" ? "सर्व Payment Methods" : "All Payment Methods"}</option>
            <option value="CASH">Cash</option>
            <option value="UPI">UPI</option>
            <option value="BANK_TRANSFER">Bank Transfer</option>
            <option value="OTHER">Other</option>
          </select>
        </div>
      </div>

      {status === "loading" && <LoadingState />}
      {status === "error" && <ErrorState message={errorMsg} onRetry={load} />}
      {status === "ready" && result && result.items.length === 0 && <EmptyState />}

      {status === "ready" && result && result.items.length > 0 && (
        <div className="card divide-y divide-marigold-100/60 dark:divide-white/5">
          {result.items.map((expense) => (
            <button
              key={expense.id}
              onClick={() => navigate(`/expenses/${expense.id}`)}
              className="w-full flex items-center justify-between gap-3 px-4 py-3 text-left hover:bg-marigold-50 dark:hover:bg-white/5 transition"
            >
              <div className="min-w-0">
                <p className="font-medium truncate">{expense.description}</p>
                <p className="text-xs text-ink/50 dark:text-cream-100/50">
                  {language === "mr" ? expense.category.nameMr : expense.category.nameEn} ·{" "}
                  {formatDate(expense.date)} · {expense.paymentMethod.replace("_", " ")}
                </p>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <span className="font-semibold text-maroon-600 dark:text-marigold-300">
                  {formatInr(expense.amount)}
                </span>
                {hasRole("ADMIN") && (
                  <span
                    role="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDelete(expense.id);
                    }}
                    className="text-ink/30 hover:text-red-600 p-1"
                  >
                    <Trash2 size={16} />
                  </span>
                )}
              </div>
            </button>
          ))}
        </div>
      )}

      {status === "ready" && result && result.total > PAGE_SIZE && (
        <div className="flex items-center justify-center gap-3 text-sm">
          <button
            disabled={page <= 1}
            onClick={() => setPage((p) => p - 1)}
            className="btn-secondary px-3 py-1.5 disabled:opacity-40"
          >
            ←
          </button>
          <span className="text-ink/60 dark:text-cream-100/60">
            {page} / {Math.ceil(result.total / PAGE_SIZE)}
          </span>
          <button
            disabled={page >= Math.ceil(result.total / PAGE_SIZE)}
            onClick={() => setPage((p) => p + 1)}
            className="btn-secondary px-3 py-1.5 disabled:opacity-40"
          >
            →
          </button>
        </div>
      )}
    </div>
  );
}
