import { Check, Pencil, Plus, Upload, X } from "lucide-react";
import { FormEvent, useEffect, useRef, useState } from "react";
import { FormField } from "../../components/FormField";
import { LoadingState } from "../../components/StateViews";
import { useBranding } from "../../context/BrandingContext";
import { useLanguage } from "../../context/LanguageContext";
import { useToast } from "../../context/ToastContext";
import {
  Category,
  createCategory,
  deactivateCategory,
  listCategories,
  updateCategory,
} from "../../services/api/categories";
import { apiErrorMessage } from "../../services/api/client";
import {
  fetchSettings,
  Settings as SettingsType,
  updateSettings,
  uploadDeviPhoto,
  uploadLogo,
} from "../../services/api/settings";

export default function Settings() {
  const { language, t } = useLanguage();
  const { showToast } = useToast();
  const { refresh: refreshBranding, deviPhotoUrl, logoUrl } = useBranding();

  const [settings, setSettings] = useState<SettingsType | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [status, setStatus] = useState<"loading" | "ready">("loading");
  const [isSavingBranding, setIsSavingBranding] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [newCategory, setNewCategory] = useState({ nameMr: "", nameEn: "" });
  const [editingCategoryId, setEditingCategoryId] = useState<string | null>(null);
  const [editDraft, setEditDraft] = useState({ nameMr: "", nameEn: "" });

  const photoInputRef = useRef<HTMLInputElement>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);

  function loadAll() {
    Promise.all([fetchSettings(), listCategories(true)])
      .then(([s, cats]) => {
        setSettings(s);
        setCategories(cats);
        setStatus("ready");
      })
      .catch((err) => showToast(apiErrorMessage(err), "error"));
  }

  useEffect(loadAll, []);

  async function handleBrandingSubmit(e: FormEvent) {
    e.preventDefault();
    if (!settings) return;
    setIsSavingBranding(true);
    try {
      const updated = await updateSettings({
        mandalName: settings.mandalName,
        deviName: settings.deviName,
        address: settings.address || undefined,
        contactNumber: settings.contactNumber || undefined,
        financialYear: settings.financialYear,
      });
      setSettings(updated);
      refreshBranding();
      showToast(language === "mr" ? "Settings save झाल्या" : "Settings saved");
    } catch (err) {
      showToast(apiErrorMessage(err), "error");
    } finally {
      setIsSavingBranding(false);
    }
  }

  async function handlePhotoChange(file: File | null) {
    if (!file) return;
    setUploadingPhoto(true);
    try {
      const updated = await uploadDeviPhoto(file);
      setSettings(updated);
      refreshBranding();
      showToast(language === "mr" ? "देवीचा फोटो update झाला" : "Devi photo updated");
    } catch (err) {
      showToast(apiErrorMessage(err), "error");
    } finally {
      setUploadingPhoto(false);
    }
  }

  async function handleLogoChange(file: File | null) {
    if (!file) return;
    setUploadingLogo(true);
    try {
      const updated = await uploadLogo(file);
      setSettings(updated);
      refreshBranding();
      showToast(language === "mr" ? "Logo update झाला" : "Logo updated");
    } catch (err) {
      showToast(apiErrorMessage(err), "error");
    } finally {
      setUploadingLogo(false);
    }
  }

  async function handleAddCategory(e: FormEvent) {
    e.preventDefault();
    if (!newCategory.nameMr.trim() || !newCategory.nameEn.trim()) return;
    try {
      const created = await createCategory(newCategory);
      setCategories((prev) => [...prev, created]);
      setNewCategory({ nameMr: "", nameEn: "" });
      showToast(language === "mr" ? "Category जोडली" : "Category added");
    } catch (err) {
      showToast(apiErrorMessage(err), "error");
    }
  }

  async function handleSaveCategoryEdit(id: string) {
    try {
      const updated = await updateCategory(id, editDraft);
      setCategories((prev) => prev.map((c) => (c.id === id ? updated : c)));
      setEditingCategoryId(null);
      showToast(language === "mr" ? "Category update केली" : "Category updated");
    } catch (err) {
      showToast(apiErrorMessage(err), "error");
    }
  }

  async function handleToggleActive(cat: Category) {
    try {
      if (cat.isActive) {
        await deactivateCategory(cat.id);
        setCategories((prev) => prev.map((c) => (c.id === cat.id ? { ...c, isActive: false } : c)));
        showToast(language === "mr" ? "Category deactivate केली" : "Category deactivated");
      } else {
        const updated = await updateCategory(cat.id, { isActive: true });
        setCategories((prev) => prev.map((c) => (c.id === cat.id ? updated : c)));
        showToast(language === "mr" ? "Category activate केली" : "Category activated");
      }
    } catch (err) {
      showToast(apiErrorMessage(err), "error");
    }
  }

  if (status === "loading" || !settings) return <LoadingState />;

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h1 className="text-xl font-display font-semibold text-maroon-700 dark:text-marigold-300">
        {t.nav.settings}
      </h1>

      {/* Branding section */}
      <div className="card card-gold-edge p-5 space-y-5">
        <h2 className="font-display font-semibold">
          {language === "mr" ? "मंडळ Branding" : "Mandal Branding"}
        </h2>

        <div className="flex items-center gap-6 flex-wrap">
          <div className="flex flex-col items-center gap-2">
            <img
              src={deviPhotoUrl}
              alt="Devi"
              className="h-24 w-24 rounded-full object-cover border-2 border-marigold-300"
            />
            <button
              type="button"
              onClick={() => photoInputRef.current?.click()}
              disabled={uploadingPhoto}
              className="btn-secondary text-xs px-3 py-1.5"
            >
              <Upload size={13} />
              {uploadingPhoto ? "..." : language === "mr" ? "देवीचा फोटो बदला" : "Change Devi Photo"}
            </button>
            <input
              ref={photoInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => handlePhotoChange(e.target.files?.[0] || null)}
            />
          </div>

          <div className="flex flex-col items-center gap-2">
            <div className="h-24 w-24 rounded-full bg-marigold-50 dark:bg-white/5 flex items-center justify-center overflow-hidden border-2 border-marigold-100 dark:border-white/10">
              {logoUrl ? (
                <img src={logoUrl} alt="Logo" className="h-full w-full object-cover" />
              ) : (
                <span className="text-xs text-ink/30">{language === "mr" ? "Logo नाही" : "No logo"}</span>
              )}
            </div>
            <button
              type="button"
              onClick={() => logoInputRef.current?.click()}
              disabled={uploadingLogo}
              className="btn-secondary text-xs px-3 py-1.5"
            >
              <Upload size={13} />
              {uploadingLogo ? "..." : language === "mr" ? "Logo बदला" : "Change Logo"}
            </button>
            <input
              ref={logoInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => handleLogoChange(e.target.files?.[0] || null)}
            />
          </div>
        </div>

        <form onSubmit={handleBrandingSubmit} className="space-y-4">
          <FormField label={language === "mr" ? "मंडळाचे नाव" : "Mandal Name"} htmlFor="mandalName" required>
            <input
              id="mandalName"
              value={settings.mandalName}
              onChange={(e) => setSettings({ ...settings, mandalName: e.target.value })}
              className="input-field"
            />
          </FormField>
          <FormField label={language === "mr" ? "देवीचे नाव" : "Devi Name"} htmlFor="deviName" required>
            <input
              id="deviName"
              value={settings.deviName}
              onChange={(e) => setSettings({ ...settings, deviName: e.target.value })}
              className="input-field"
            />
          </FormField>
          <div className="grid grid-cols-2 gap-3">
            <FormField label={language === "mr" ? "संपर्क क्रमांक" : "Contact Number"} htmlFor="contactNumber">
              <input
                id="contactNumber"
                value={settings.contactNumber || ""}
                onChange={(e) => setSettings({ ...settings, contactNumber: e.target.value })}
                className="input-field"
              />
            </FormField>
            <FormField label={language === "mr" ? "Financial Year" : "Financial Year"} htmlFor="financialYear">
              <input
                id="financialYear"
                value={settings.financialYear}
                onChange={(e) => setSettings({ ...settings, financialYear: e.target.value })}
                className="input-field"
                placeholder="2026-27"
              />
            </FormField>
          </div>
          <FormField label={language === "mr" ? "पत्ता" : "Address"} htmlFor="address">
            <input
              id="address"
              value={settings.address || ""}
              onChange={(e) => setSettings({ ...settings, address: e.target.value })}
              className="input-field"
            />
          </FormField>
          <button type="submit" disabled={isSavingBranding} className="btn-primary w-full">
            {isSavingBranding ? "..." : t.common.save}
          </button>
        </form>
      </div>

      {/* Categories section */}
      <div className="card card-gold-edge p-5 space-y-4">
        <h2 className="font-display font-semibold">
          {language === "mr" ? "Expense Categories" : "Expense Categories"}
        </h2>

        <ul className="divide-y divide-marigold-100/60 dark:divide-white/5">
          {categories.map((cat) => (
            <li key={cat.id} className="py-2.5 flex items-center justify-between gap-2">
              {editingCategoryId === cat.id ? (
                <div className="flex-1 flex gap-2">
                  <input
                    value={editDraft.nameMr}
                    onChange={(e) => setEditDraft({ ...editDraft, nameMr: e.target.value })}
                    className="input-field py-1.5 text-sm"
                    placeholder="मराठी"
                  />
                  <input
                    value={editDraft.nameEn}
                    onChange={(e) => setEditDraft({ ...editDraft, nameEn: e.target.value })}
                    className="input-field py-1.5 text-sm"
                    placeholder="English"
                  />
                  <button onClick={() => handleSaveCategoryEdit(cat.id)} className="text-emerald-600 p-1">
                    <Check size={16} />
                  </button>
                  <button onClick={() => setEditingCategoryId(null)} className="text-ink/40 p-1">
                    <X size={16} />
                  </button>
                </div>
              ) : (
                <>
                  <span className={`text-sm ${!cat.isActive ? "opacity-40 line-through" : ""}`}>
                    {cat.nameMr} / {cat.nameEn}
                  </span>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => {
                        setEditingCategoryId(cat.id);
                        setEditDraft({ nameMr: cat.nameMr, nameEn: cat.nameEn });
                      }}
                      className="text-ink/40 hover:text-maroon-600 p-1"
                    >
                      <Pencil size={14} />
                    </button>
                    <button
                      onClick={() => handleToggleActive(cat)}
                      className={`text-xs px-2 py-1 rounded-full ${
                        cat.isActive
                          ? "bg-red-50 text-red-600 dark:bg-red-500/10"
                          : "bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10"
                      }`}
                    >
                      {cat.isActive
                        ? language === "mr"
                          ? "Deactivate"
                          : "Deactivate"
                        : language === "mr"
                        ? "Activate"
                        : "Activate"}
                    </button>
                  </div>
                </>
              )}
            </li>
          ))}
        </ul>

        <form onSubmit={handleAddCategory} className="flex gap-2 pt-2">
          <input
            value={newCategory.nameMr}
            onChange={(e) => setNewCategory({ ...newCategory, nameMr: e.target.value })}
            placeholder={language === "mr" ? "मराठी नाव" : "Marathi name"}
            className="input-field text-sm py-2"
          />
          <input
            value={newCategory.nameEn}
            onChange={(e) => setNewCategory({ ...newCategory, nameEn: e.target.value })}
            placeholder="English name"
            className="input-field text-sm py-2"
          />
          <button type="submit" className="btn-primary px-3 py-2 shrink-0">
            <Plus size={16} />
          </button>
        </form>
      </div>
    </div>
  );
}
