import { Plus, Trash2, UserRound } from "lucide-react";
import { FormEvent, useEffect, useState } from "react";
import { EmptyState, ErrorState, LoadingState } from "../../components/StateViews";
import { FormField } from "../../components/FormField";
import { useLanguage } from "../../context/LanguageContext";
import { useToast } from "../../context/ToastContext";
import { apiErrorMessage } from "../../services/api/client";
import { createMember, deleteMember, listMembers, Member } from "../../services/api/members";

export default function MembersList() {
  const { t, language } = useLanguage();
  const { showToast } = useToast();

  const [members, setMembers] = useState<Member[]>([]);
  const [status, setStatus] = useState<"loading" | "error" | "ready">("loading");
  const [errorMsg, setErrorMsg] = useState<string>();
  const [showForm, setShowForm] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [form, setForm] = useState({ name: "", mobile: "", email: "", address: "" });

  function load() {
    setStatus("loading");
    listMembers()
      .then((data) => {
        setMembers(data);
        setStatus("ready");
      })
      .catch((err) => {
        setErrorMsg(apiErrorMessage(err));
        setStatus("error");
      });
  }

  useEffect(load, []);

  function validate(): boolean {
    const next: Record<string, string> = {};
    const req = language === "mr" ? "ही माहिती आवश्यक आहे" : "This field is required";
    if (!form.name.trim()) next.name = req;
    if (!/^[0-9]{10}$/.test(form.mobile)) {
      next.mobile = language === "mr" ? "Mobile number 10 अंकी असावा" : "Mobile number must be 10 digits";
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!validate()) return;
    setIsSubmitting(true);
    try {
      const formData = new FormData();
      formData.append("name", form.name);
      formData.append("mobile", form.mobile);
      if (form.email) formData.append("email", form.email);
      if (form.address) formData.append("address", form.address);
      await createMember(formData);
      showToast(language === "mr" ? "Member जोडला" : "Member added");
      setForm({ name: "", mobile: "", email: "", address: "" });
      setShowForm(false);
      load();
    } catch (err) {
      showToast(apiErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleDelete(id: string) {
    if (!window.confirm(language === "mr" ? "हा member काढायचा आहे का?" : "Remove this member?")) return;
    try {
      await deleteMember(id);
      showToast(language === "mr" ? "Member काढला" : "Member removed");
      load();
    } catch (err) {
      showToast(apiErrorMessage(err), "error");
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h1 className="text-xl font-display font-semibold text-maroon-700 dark:text-marigold-300">{t.nav.members}</h1>
        <button onClick={() => setShowForm((v) => !v)} className="btn-primary text-sm px-4 py-2.5">
          <Plus size={16} /> {t.dashboard.addMember}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="card card-gold-edge p-5 space-y-4">
          <FormField label={language === "mr" ? "नाव" : "Name"} htmlFor="name" required error={errors.name}>
            <input id="name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input-field" />
          </FormField>
          <FormField label="Mobile Number" htmlFor="mobile" required error={errors.mobile}>
            <input id="mobile" value={form.mobile} onChange={(e) => setForm({ ...form, mobile: e.target.value })} className="input-field" placeholder="9876543210" />
          </FormField>
          <FormField label="Email" htmlFor="email">
            <input id="email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="input-field" />
          </FormField>
          <FormField label={language === "mr" ? "पत्ता" : "Address"} htmlFor="address">
            <input id="address" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className="input-field" />
          </FormField>
          <div className="flex gap-3">
            <button type="submit" disabled={isSubmitting} className="btn-primary flex-1">{isSubmitting ? "..." : t.common.save}</button>
            <button type="button" onClick={() => setShowForm(false)} className="btn-secondary flex-1">{t.common.cancel}</button>
          </div>
        </form>
      )}

      {status === "loading" && <LoadingState />}
      {status === "error" && <ErrorState message={errorMsg} onRetry={load} />}
      {status === "ready" && members.length === 0 && <EmptyState />}

      {status === "ready" && members.length > 0 && (
        <div className="card divide-y divide-marigold-100/60 dark:divide-white/5">
          {members.map((m) => (
            <div key={m.id} className="flex items-center justify-between gap-3 px-4 py-3">
              <div className="flex items-center gap-3 min-w-0">
                <div className="h-9 w-9 rounded-full bg-marigold-50 dark:bg-white/5 flex items-center justify-center text-marigold-600 dark:text-marigold-300 shrink-0">
                  {m.photoUrl ? (
                    <img src={m.photoUrl} alt={m.name} className="h-9 w-9 rounded-full object-cover" />
                  ) : (
                    <UserRound size={18} />
                  )}
                </div>
                <div className="min-w-0">
                  <p className="font-medium truncate">{m.name}</p>
                  <p className="text-xs text-ink/50 dark:text-cream-100/50">{m.mobile}</p>
                </div>
              </div>
              <button onClick={() => handleDelete(m.id)} className="text-ink/30 hover:text-red-600 p-1 shrink-0">
                <Trash2 size={16} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
