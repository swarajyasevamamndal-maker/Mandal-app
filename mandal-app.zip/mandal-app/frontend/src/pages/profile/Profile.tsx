import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { useLanguage } from "../../context/LanguageContext";

export default function Profile() {
  const { user, logout } = useAuth();
  const { language, t } = useLanguage();
  const navigate = useNavigate();

  if (!user) return null;

  const rows: [string, string][] = [
    [language === "mr" ? "नाव" : "Name", user.name],
    [language === "mr" ? "Email" : "Email", user.email],
    ...(user.phone ? ([[language === "mr" ? "फोन" : "Phone", user.phone]] as [string, string][]) : []),
    [language === "mr" ? "भूमिका" : "Role", user.role],
  ];

  return (
    <div className="max-w-md mx-auto space-y-4">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1.5 text-sm text-ink/60 dark:text-cream-100/60">
        <ArrowLeft size={16} /> {language === "mr" ? "मागे" : "Back"}
      </button>

      <div className="card card-gold-edge p-6 text-center">
        <div className="h-16 w-16 rounded-full bg-maroon-600 text-white text-xl font-semibold flex items-center justify-center mx-auto mb-3">
          {user.name.charAt(0).toUpperCase()}
        </div>
        <h1 className="font-display font-semibold text-lg">{user.name}</h1>
        <p className="text-sm text-ink/50 dark:text-cream-100/50">{user.role}</p>
      </div>

      <div className="card p-5">
        <dl className="divide-y divide-marigold-100/60 dark:divide-white/5">
          {rows.map(([label, value]) => (
            <div key={label} className="flex justify-between py-2.5 text-sm">
              <dt className="text-ink/50 dark:text-cream-100/50">{label}</dt>
              <dd className="font-medium">{value}</dd>
            </div>
          ))}
        </dl>
      </div>

      <button onClick={logout} className="btn-secondary w-full text-red-600 dark:text-red-400">
        {t.nav.logout}
      </button>
    </div>
  );
}
