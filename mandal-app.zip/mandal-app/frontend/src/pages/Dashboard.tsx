import { Banknote, HandCoins, PiggyBank, QrCode, Users, Wallet } from "lucide-react";
import { useEffect, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { useNavigate } from "react-router-dom";
import { StatCard } from "../components/StatCard";
import { EmptyState, ErrorState, LoadingState } from "../components/StateViews";
import { useAuth } from "../context/AuthContext";
import { useLanguage } from "../context/LanguageContext";
import { fetchDashboardSummary } from "../services/api/dashboard";
import { apiErrorMessage } from "../services/api/client";
import { DashboardSummary } from "../types";
import { formatDate, formatInr } from "../utils/format";

export default function Dashboard() {
  const { t } = useLanguage();
  const { hasRole } = useAuth();
  const navigate = useNavigate();

  const [data, setData] = useState<DashboardSummary | null>(null);
  const [status, setStatus] = useState<"loading" | "error" | "ready">("loading");
  const [errorMsg, setErrorMsg] = useState<string | undefined>();

  function load() {
    setStatus("loading");
    fetchDashboardSummary()
      .then((summary) => {
        setData(summary);
        setStatus("ready");
      })
      .catch((err) => {
        setErrorMsg(apiErrorMessage(err));
        setStatus("error");
      });
  }

  useEffect(load, []);

  if (status === "loading") return <LoadingState />;
  if (status === "error") return <ErrorState message={errorMsg} onRetry={load} />;
  if (!data) return null;

  const canManageFinances = hasRole("ADMIN", "TREASURER");

  const quickActions = [
    canManageFinances && { label: t.dashboard.addExpense, to: "/expenses/new" },
    canManageFinances && { label: t.dashboard.addDonation, to: "/donations/new" },
    canManageFinances && { label: t.dashboard.addUpi, to: "/upi/new" },
    hasRole("ADMIN") && { label: t.dashboard.addMember, to: "/members" },
    { label: t.dashboard.addEvent, to: "/events" },
  ].filter(Boolean) as { label: string; to: string }[];

  return (
    <div className="space-y-6 animate-[fadeIn_0.3s_ease-out]">
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
        <StatCard icon={<HandCoins size={18} />} label={t.dashboard.totalIncome} value={formatInr(data.totalIncome)} tone="positive" />
        <StatCard icon={<Banknote size={18} />} label={t.dashboard.totalExpense} value={formatInr(data.totalExpenses)} tone="warning" />
        <StatCard icon={<Wallet size={18} />} label={t.dashboard.currentBalance} value={formatInr(data.currentBalance)} />
        <StatCard icon={<QrCode size={18} />} label={t.dashboard.upiBalance} value={formatInr(data.upiBalance)} />
        <StatCard icon={<PiggyBank size={18} />} label={t.dashboard.cashBalance} value={formatInr(data.cashBalance)} />
        <StatCard icon={<Users size={18} />} label={t.dashboard.totalDonations} value={formatInr(data.totalDonations)} tone="positive" />
      </div>

      {/* Quick actions */}
      <div>
        <h2 className="text-sm font-semibold text-ink/60 dark:text-cream-100/60 mb-2">
          {t.dashboard.quickActions}
        </h2>
        <div className="flex flex-wrap gap-2">
          {quickActions.map((action) => (
            <button key={action.to} onClick={() => navigate(action.to)} className="btn-secondary text-sm px-4 py-2">
              + {action.label}
            </button>
          ))}
        </div>
      </div>

      {/* Monthly chart */}
      <div className="card card-gold-edge p-4">
        <h2 className="font-display font-semibold text-maroon-700 dark:text-marigold-300 mb-3">
          {t.dashboard.monthlyChart}
        </h2>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.monthly}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(110,20,35,0.08)" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip formatter={(value: number) => formatInr(value)} />
              <Legend />
              <Bar dataKey="income" name={t.dashboard.totalIncome} fill="#C98A2B" radius={[4, 4, 0, 0]} />
              <Bar dataKey="expense" name={t.dashboard.totalExpense} fill="#6E1423" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="card card-gold-edge p-4">
          <h2 className="font-display font-semibold text-maroon-700 dark:text-marigold-300 mb-3">
            {t.dashboard.recentExpenses}
          </h2>
          {data.recentExpenses.length === 0 ? (
            <EmptyState />
          ) : (
            <ul className="divide-y divide-marigold-100/60 dark:divide-white/5">
              {data.recentExpenses.map((e) => (
                <li key={e.id} className="py-2.5 flex items-center justify-between text-sm">
                  <div className="min-w-0">
                    <p className="font-medium truncate">{e.description}</p>
                    <p className="text-xs text-ink/50 dark:text-cream-100/50">
                      {e.category} · {formatDate(e.date)}
                    </p>
                  </div>
                  <span className="font-semibold text-maroon-600 dark:text-marigold-300 shrink-0 ml-2">
                    -{formatInr(e.amount)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="card card-gold-edge p-4">
          <h2 className="font-display font-semibold text-maroon-700 dark:text-marigold-300 mb-3">
            {t.dashboard.recentDonations}
          </h2>
          {data.recentDonations.length === 0 ? (
            <EmptyState />
          ) : (
            <ul className="divide-y divide-marigold-100/60 dark:divide-white/5">
              {data.recentDonations.map((d) => (
                <li key={d.id} className="py-2.5 flex items-center justify-between text-sm">
                  <div className="min-w-0">
                    <p className="font-medium truncate">{d.donorName}</p>
                    <p className="text-xs text-ink/50 dark:text-cream-100/50">
                      {d.receiptNumber} · {formatDate(d.date)}
                    </p>
                  </div>
                  <span className="font-semibold text-emerald-700 dark:text-emerald-400 shrink-0 ml-2">
                    +{formatInr(d.amount)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
