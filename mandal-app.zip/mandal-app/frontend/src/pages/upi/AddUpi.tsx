import { AlertCircle, ArrowLeft, CheckCircle2, Upload } from "lucide-react";
import { FormEvent, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { FormField } from "../../components/FormField";
import { useLanguage } from "../../context/LanguageContext";
import { useToast } from "../../context/ToastContext";
import { apiErrorMessage } from "../../services/api/client";
import { checkDuplicateUtr, createUpiTransaction } from "../../services/api/upiTransactions";

const upiApps = ["Google Pay", "PhonePe", "Paytm", "Bank UPI", "Other"];

export default function AddUpi() {
  const { t, language } = useLanguage();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [utrStatus, setUtrStatus] = useState<"idle" | "checking" | "duplicate" | "ok">("idle");
  const [screenshot, setScreenshot] = useState<File | null>(null);
  const [form, setForm] = useState({
    utrNumber: "",
    date: new Date().toISOString().slice(0, 10),
    time: new Date().toTimeString().slice(0, 5),
    senderName: "",
    receiverName: "",
    amount: "",
    type: "INCOME",
    upiApp: "Google Pay",
    notes: "",
  });

  // Live duplicate check, debounced, as the user types the UTR.
  useEffect(() => {
    const utr = form.utrNumber.trim();
    if (utr.length < 4) {
      setUtrStatus("idle");
      return;
    }
    setUtrStatus("checking");
    const timer = setTimeout(() => {
      checkDuplicateUtr(utr)
        .then((res) => setUtrStatus(res.isDuplicate ? "duplicate" : "ok"))
        .catch(() => setUtrStatus("idle"));
    }, 500);
    return () => clearTimeout(timer);
  }, [form.utrNumber]);

  function validate(): boolean {
    const next: Record<string, string> = {};
    const req = language === "mr" ? "ही माहिती आवश्यक आहे" : "This field is required";

    if (!form.utrNumber.trim()) next.utrNumber = req;
    if (utrStatus === "duplicate") {
      next.utrNumber = language === "mr" ? "हा UTR आधीच नोंदवलेला आहे" : "This UTR is already recorded";
    }
    if (!form.date) next.date = req;
    if (!form.time) next.time = req;
    const amountNum = Number(form.amount);
    if (!form.amount || Number.isNaN(amountNum) || amountNum <= 0) {
      next.amount = language === "mr" ? "योग्य रक्कम टाका (0 पेक्षा जास्त)" : "Enter a valid amount greater than 0";
    }

    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    try {
      const formData = new FormData();
      formData.append("utrNumber", form.utrNumber.trim());
      formData.append("date", form.date);
      formData.append("time", form.time);
      if (form.senderName) formData.append("senderName", form.senderName);
      if (form.receiverName) formData.append("receiverName", form.receiverName);
      formData.append("amount", form.amount);
      formData.append("type", form.type);
      formData.append("upiApp", form.upiApp);
      if (form.notes) formData.append("notes", form.notes);
      if (screenshot) formData.append("screenshot", screenshot);

      await createUpiTransaction(formData);
      showToast(language === "mr" ? "UPI Transaction जोडली" : "UPI Transaction added");
      navigate("/upi");
    } catch (err) {
      showToast(apiErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="max-w-xl mx-auto space-y-4">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1.5 text-sm text-ink/60 dark:text-cream-100/60">
        <ArrowLeft size={16} /> {language === "mr" ? "मागे" : "Back"}
      </button>

      <h1 className="text-xl font-display font-semibold text-maroon-700 dark:text-marigold-300">{t.dashboard.addUpi}</h1>

      <form onSubmit={handleSubmit} className="card card-gold-edge p-5 space-y-4">
        <FormField label="UTR / Transaction ID" htmlFor="utrNumber" required error={errors.utrNumber}>
          <div className="relative">
            <input
              id="utrNumber"
              value={form.utrNumber}
              onChange={(e) => setForm({ ...form, utrNumber: e.target.value })}
              className="input-field pr-9"
            />
            {utrStatus === "duplicate" && <AlertCircle size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-red-500" />}
            {utrStatus === "ok" && <CheckCircle2 size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-emerald-500" />}
          </div>
          {utrStatus === "duplicate" && !errors.utrNumber && (
            <p className="text-xs text-red-600 dark:text-red-400 mt-1">
              {language === "mr" ? "हा UTR आधीच नोंदवलेला आहे — duplicate transaction" : "This UTR is already recorded — duplicate transaction"}
            </p>
          )}
        </FormField>

        <div className="grid grid-cols-2 gap-3">
          <FormField label={language === "mr" ? "तारीख" : "Date"} htmlFor="date" required error={errors.date}>
            <input id="date" type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className="input-field" />
          </FormField>
          <FormField label={language === "mr" ? "वेळ" : "Time"} htmlFor="time" required error={errors.time}>
            <input id="time" type="time" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} className="input-field" />
          </FormField>
        </div>

        <FormField label={language === "mr" ? "रक्कम (₹)" : "Amount (₹)"} htmlFor="amount" required error={errors.amount}>
          <input id="amount" type="number" min="0" step="0.01" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} className="input-field" />
        </FormField>

        <div className="grid grid-cols-2 gap-3">
          <FormField label={language === "mr" ? "प्रकार" : "Type"} htmlFor="type" required>
            <select id="type" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className="input-field">
              <option value="INCOME">{language === "mr" ? "जमा (Income)" : "Income"}</option>
              <option value="EXPENSE">{language === "mr" ? "खर्च (Expense)" : "Expense"}</option>
            </select>
          </FormField>
          <FormField label="UPI App" htmlFor="upiApp" required>
            <select id="upiApp" value={form.upiApp} onChange={(e) => setForm({ ...form, upiApp: e.target.value })} className="input-field">
              {upiApps.map((app) => <option key={app} value={app}>{app}</option>)}
            </select>
          </FormField>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <FormField label={language === "mr" ? "पाठवणारा" : "Sender Name"} htmlFor="senderName">
            <input id="senderName" value={form.senderName} onChange={(e) => setForm({ ...form, senderName: e.target.value })} className="input-field" />
          </FormField>
          <FormField label={language === "mr" ? "स्वीकारणारा" : "Receiver Name"} htmlFor="receiverName">
            <input id="receiverName" value={form.receiverName} onChange={(e) => setForm({ ...form, receiverName: e.target.value })} className="input-field" />
          </FormField>
        </div>

        <FormField label={language === "mr" ? "टीप" : "Notes"} htmlFor="notes">
          <textarea id="notes" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="input-field" rows={2} />
        </FormField>

        <FormField label={language === "mr" ? "Screenshot" : "Screenshot"} htmlFor="screenshot">
          <label className="flex items-center gap-2 justify-center border-2 border-dashed border-marigold-200 dark:border-white/10 rounded-xl px-4 py-4 cursor-pointer text-sm text-ink/50 dark:text-cream-100/50 hover:border-marigold-400">
            <Upload size={16} />
            {screenshot ? screenshot.name : language === "mr" ? "Screenshot निवडा" : "Choose screenshot"}
            <input
              id="screenshot"
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => setScreenshot(e.target.files?.[0] || null)}
            />
          </label>
        </FormField>

        <div className="flex gap-3 pt-2">
          <button type="submit" disabled={isSubmitting || utrStatus === "duplicate"} className="btn-primary flex-1">
            {isSubmitting ? "..." : t.common.save}
          </button>
          <button type="button" onClick={() => navigate(-1)} className="btn-secondary flex-1">{t.common.cancel}</button>
        </div>
      </form>
    </div>
  );
}
