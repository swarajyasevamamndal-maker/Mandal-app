import { Plus, Search } from "lucide-react";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { EmptyState, ErrorState, LoadingState } from "../../components/StateViews";
import { useAuth } from "../../context/AuthContext";
import { useLanguage } from "../../context/LanguageContext";
import { apiErrorMessage } from "../../services/api/client";
import { listUpiTransactions } from "../../services/api/upiTransactions";
import { PaginatedResponse, UpiTransaction } from "../../types";
import { formatDate, formatInr } from "../../utils/format";

const PAGE_SIZE = 15;

const statusStyles: Record<string, string> = {
  SUCCESS: "bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400",
  PENDING: "bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-400",
  FAILED: "bg-red-50 text-red-700 dark:bg-red-500/10 dark:text-red-400",
};

export default function UpiList() {
  const { t, language } = useLanguage();
  const { hasRole } = useAuth();
  const navigate = useNavigate();

  const [result, setResult] = useState<PaginatedResponse<UpiTransaction> | null>(null);
  const [status, setStatus] = useState<"loading" | "error" | "ready">("loading");
  const [errorMsg, setErrorMsg] = useState<string>();
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);

  function load() {
    setStatus("loading");
    listUpiTransactions({ page, pageSize: PAGE_SIZE, search: search || undefined, sortBy: "date", sortOrder: "desc" })
      .then((data) => {
        setResult(data);
        setStatus("ready");
      })
      .catch((err) => {
        setErrorMsg(apiErrorMessage(err));
        setStatus("error");
      });
  }

  useEffect(load, [page]);

  function handleSearchSubmit(e: React.FormEvent) {
    e.preventDefault();
    setPage(1);
    load();
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h1 className="text-xl font-display font-semibold text-maroon-700 dark:text-marigold-300">{t.nav.upi}</h1>
        {hasRole("ADMIN", "TREASURER") && (
          <button onClick={() => navigate("/upi/new")} className="btn-primary text-sm px-4 py-2.5">
            <Plus size={16} /> {t.dashboard.addUpi}
          </button>
        )}
      </div>

      <form onSubmit={handleSearchSubmit} className="card p-3 relative">
        <Search size={16} className="absolute left-6 top-1/2 -translate-y-1/2 text-ink/40" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={language === "mr" ? "UTR / नाव शोधा..." : "Search UTR / name..."}
          className="input-field pl-9"
        />
      </form>

      {status === "loading" && <LoadingState />}
      {status === "error" && <ErrorState message={errorMsg} onRetry={load} />}
      {status === "ready" && result && result.items.length === 0 && <EmptyState />}

      {status === "ready" && result && result.items.length > 0 && (
        <div className="card divide-y divide-marigold-100/60 dark:divide-white/5">
          {result.items.map((txn) => (
            <div key={txn.id} className="flex items-center justify-between gap-3 px-4 py-3">
              <div className="min-w-0">
                <p className="font-medium truncate">{txn.utrNumber}</p>
                <p className="text-xs text-ink/50 dark:text-cream-100/50">
                  {txn.upiApp} · {formatDate(txn.date)} · {txn.time}
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className={`text-xs px-2 py-1 rounded-full ${statusStyles[txn.status]}`}>{txn.status}</span>
                <span className={`font-semibold ${txn.type === "INCOME" ? "text-emerald-700 dark:text-emerald-400" : "text-maroon-600 dark:text-marigold-300"}`}>
                  {txn.type === "INCOME" ? "+" : "-"}{formatInr(txn.amount)}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {status === "ready" && result && result.total > PAGE_SIZE && (
        <div className="flex items-center justify-center gap-3 text-sm">
          <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="btn-secondary px-3 py-1.5 disabled:opacity-40">←</button>
          <span className="text-ink/60 dark:text-cream-100/60">{page} / {Math.ceil(result.total / PAGE_SIZE)}</span>
          <button disabled={page >= Math.ceil(result.total / PAGE_SIZE)} onClick={() => setPage((p) => p + 1)} className="btn-secondary px-3 py-1.5 disabled:opacity-40">→</button>
        </div>
      )}
    </div>
  );
}
