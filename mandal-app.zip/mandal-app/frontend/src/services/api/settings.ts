import { apiClient } from "./client";

export interface Settings {
  id: string;
  mandalName: string;
  deviName: string;
  logoUrl?: string | null;
  deviPhotoUrl?: string | null;
  address?: string | null;
  contactNumber?: string | null;
  financialYear: string;
  currency: string;
  defaultLanguage: string;
}

export interface PublicBranding {
  mandalName: string;
  deviName: string;
  logoUrl?: string | null;
  deviPhotoUrl?: string | null;
}

export async function fetchPublicBranding() {
  const { data } = await apiClient.get<PublicBranding>("/settings/public");
  return data;
}

export async function fetchSettings() {
  const { data } = await apiClient.get<Settings>("/settings");
  return data;
}

export async function updateSettings(payload: Partial<Settings>) {
  const { data } = await apiClient.put<Settings>("/settings", payload);
  return data;
}

export async function uploadDeviPhoto(file: File) {
  const formData = new FormData();
  formData.append("photo", file);
  const { data } = await apiClient.post<Settings>("/settings/devi-photo", formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return data;
}

export async function uploadLogo(file: File) {
  const formData = new FormData();
  formData.append("logo", file);
  const { data } = await apiClient.post<Settings>("/settings/logo", formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return data;
}
