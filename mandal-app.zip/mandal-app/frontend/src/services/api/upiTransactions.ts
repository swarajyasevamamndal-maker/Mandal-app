import { apiClient } from "./client";
import { PaginatedResponse, UpiTransaction } from "../../types";

export interface UpiFilters {
  page?: number;
  pageSize?: number;
  search?: string;
  type?: "INCOME" | "EXPENSE";
  status?: string;
  dateFrom?: string;
  dateTo?: string;
  sortBy?: "date" | "amount";
  sortOrder?: "asc" | "desc";
}

export async function listUpiTransactions(filters: UpiFilters = {}) {
  const { data } = await apiClient.get<PaginatedResponse<UpiTransaction>>("/upi-transactions", {
    params: filters,
  });
  return data;
}

export async function checkDuplicateUtr(utr: string) {
  const { data } = await apiClient.get<{ isDuplicate: boolean; existing: UpiTransaction | null }>(
    "/upi-transactions/check-duplicate",
    { params: { utr } }
  );
  return data;
}

export async function createUpiTransaction(payload: FormData | Record<string, unknown>) {
  const { data } = await apiClient.post<UpiTransaction>("/upi-transactions", payload, {
    headers: payload instanceof FormData ? { "Content-Type": "multipart/form-data" } : undefined,
  });
  return data;
}

export async function deleteUpiTransaction(id: string) {
  await apiClient.delete(`/upi-transactions/${id}`);
}
