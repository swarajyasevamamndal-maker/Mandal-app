import { apiClient } from "./client";
import { Expense, PaginatedResponse } from "../../types";

export interface ExpenseFilters {
  page?: number;
  pageSize?: number;
  search?: string;
  categoryId?: string;
  paymentMethod?: string;
  dateFrom?: string;
  dateTo?: string;
  sortBy?: "date" | "amount";
  sortOrder?: "asc" | "desc";
}

export async function listExpenses(filters: ExpenseFilters = {}) {
  const { data } = await apiClient.get<PaginatedResponse<Expense>>("/expenses", { params: filters });
  return data;
}

export async function getExpense(id: string) {
  const { data } = await apiClient.get<Expense>(`/expenses/${id}`);
  return data;
}

export async function createExpense(payload: FormData | Record<string, unknown>) {
  const { data } = await apiClient.post<Expense>("/expenses", payload, {
    headers: payload instanceof FormData ? { "Content-Type": "multipart/form-data" } : undefined,
  });
  return data;
}

export async function updateExpense(id: string, payload: FormData | Record<string, unknown>) {
  const { data } = await apiClient.put<Expense>(`/expenses/${id}`, payload, {
    headers: payload instanceof FormData ? { "Content-Type": "multipart/form-data" } : undefined,
  });
  return data;
}

export async function deleteExpense(id: string) {
  await apiClient.delete(`/expenses/${id}`);
}
