import { apiClient } from "./client";

export interface Category {
  id: string;
  nameMr: string;
  nameEn: string;
  type: string;
  isActive: boolean;
  sortOrder: number;
}

export async function listCategories(includeInactive = false) {
  const { data } = await apiClient.get<Category[]>("/categories", {
    params: includeInactive ? { includeInactive: "true" } : undefined,
  });
  return data;
}

export async function createCategory(payload: { nameMr: string; nameEn: string }) {
  const { data } = await apiClient.post<Category>("/categories", payload);
  return data;
}

export async function updateCategory(id: string, payload: Partial<Category>) {
  const { data } = await apiClient.put<Category>(`/categories/${id}`, payload);
  return data;
}

export async function deactivateCategory(id: string) {
  await apiClient.delete(`/categories/${id}`);
}
