import { apiClient } from "./client";
import { Donation, PaginatedResponse } from "../../types";

export interface DonationFilters {
  page?: number;
  pageSize?: number;
  search?: string;
  paymentMethod?: string;
  dateFrom?: string;
  dateTo?: string;
  sortBy?: "date" | "amount" | "donorName";
  sortOrder?: "asc" | "desc";
}

export async function listDonations(filters: DonationFilters = {}) {
  const { data } = await apiClient.get<PaginatedResponse<Donation>>("/donations", { params: filters });
  return data;
}

export async function getDonation(id: string) {
  const { data } = await apiClient.get<Donation>(`/donations/${id}`);
  return data;
}

export async function createDonation(payload: Record<string, unknown>) {
  const { data } = await apiClient.post<Donation>("/donations", payload);
  return data;
}

export async function updateDonation(id: string, payload: Record<string, unknown>) {
  const { data } = await apiClient.put<Donation>(`/donations/${id}`, payload);
  return data;
}

export async function deleteDonation(id: string) {
  await apiClient.delete(`/donations/${id}`);
}

/** Downloads the receipt PDF and triggers a browser save/open. */
export async function downloadReceipt(id: string, receiptNumber: string) {
  const response = await apiClient.get(`/donations/${id}/receipt`, { responseType: "blob" });
  const url = window.URL.createObjectURL(new Blob([response.data], { type: "application/pdf" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = `receipt-${receiptNumber}.pdf`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.URL.revokeObjectURL(url);
}
