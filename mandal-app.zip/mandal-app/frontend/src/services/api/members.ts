import { apiClient } from "./client";

export interface Member {
  id: string;
  name: string;
  mobile: string;
  email?: string | null;
  address?: string | null;
  photoUrl?: string | null;
  status: string;
  joiningDate?: string | null;
}

export async function listMembers(search?: string) {
  const { data } = await apiClient.get<Member[]>("/members", { params: search ? { search } : undefined });
  return data;
}

export async function createMember(payload: FormData) {
  const { data } = await apiClient.post<Member>("/members", payload, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return data;
}

export async function updateMember(id: string, payload: Partial<Member>) {
  const { data } = await apiClient.put<Member>(`/members/${id}`, payload);
  return data;
}

export async function deleteMember(id: string) {
  await apiClient.delete(`/members/${id}`);
}
