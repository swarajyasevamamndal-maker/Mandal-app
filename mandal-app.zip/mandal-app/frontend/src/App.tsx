import { Navigate, Route, Routes } from "react-router-dom";
import { ModulePlaceholder } from "./components/ModulePlaceholder";
import AppLayout from "./layouts/AppLayout";
import Dashboard from "./pages/Dashboard";
import Login from "./pages/Login";
import AddExpense from "./pages/expenses/AddExpense";
import ExpenseDetails from "./pages/expenses/ExpenseDetails";
import ExpensesList from "./pages/expenses/ExpensesList";
import AddDonation from "./pages/donations/AddDonation";
import DonationDetails from "./pages/donations/DonationDetails";
import DonationsList from "./pages/donations/DonationsList";
import AddUpi from "./pages/upi/AddUpi";
import UpiList from "./pages/upi/UpiList";
import MembersList from "./pages/members/MembersList";
import Profile from "./pages/profile/Profile";
import Settings from "./pages/settings/Settings";
import { ProtectedRoute } from "./routes/ProtectedRoute";
import { useLanguage } from "./context/LanguageContext";

export default function App() {
  const { t } = useLanguage();

  return (
    <Routes>
      <Route path="/login" element={<Login />} />

      <Route
        element={
          <ProtectedRoute>
            <AppLayout />
          </ProtectedRoute>
        }
      >
        <Route path="/dashboard" element={<Dashboard />} />

        <Route
          path="/expenses"
          element={
            <ProtectedRoute allowedRoles={["ADMIN", "TREASURER"]}>
              <ExpensesList />
            </ProtectedRoute>
          }
        />
        <Route
          path="/expenses/new"
          element={
            <ProtectedRoute allowedRoles={["ADMIN", "TREASURER"]}>
              <AddExpense />
            </ProtectedRoute>
          }
        />
        <Route
          path="/expenses/:id/edit"
          element={
            <ProtectedRoute allowedRoles={["ADMIN", "TREASURER"]}>
              <AddExpense />
            </ProtectedRoute>
          }
        />
        <Route
          path="/expenses/:id"
          element={
            <ProtectedRoute allowedRoles={["ADMIN", "TREASURER"]}>
              <ExpenseDetails />
            </ProtectedRoute>
          }
        />

        <Route
          path="/donations"
          element={
            <ProtectedRoute allowedRoles={["ADMIN", "TREASURER"]}>
              <DonationsList />
            </ProtectedRoute>
          }
        />
        <Route
          path="/donations/new"
          element={
            <ProtectedRoute allowedRoles={["ADMIN", "TREASURER"]}>
              <AddDonation />
            </ProtectedRoute>
          }
        />
        <Route
          path="/donations/:id"
          element={
            <ProtectedRoute allowedRoles={["ADMIN", "TREASURER"]}>
              <DonationDetails />
            </ProtectedRoute>
          }
        />
        <Route
          path="/upi"
          element={
            <ProtectedRoute allowedRoles={["ADMIN", "TREASURER"]}>
              <UpiList />
            </ProtectedRoute>
          }
        />
        <Route
          path="/upi/new"
          element={
            <ProtectedRoute allowedRoles={["ADMIN", "TREASURER"]}>
              <AddUpi />
            </ProtectedRoute>
          }
        />
        <Route
          path="/members"
          element={
            <ProtectedRoute allowedRoles={["ADMIN"]}>
              <MembersList />
            </ProtectedRoute>
          }
        />
        <Route path="/events" element={<ModulePlaceholder titleKey={t.nav.events} />} />
        <Route path="/tasks" element={<ModulePlaceholder titleKey={t.nav.tasks} />} />
        <Route path="/reports" element={<ModulePlaceholder titleKey={t.nav.reports} />} />

        <Route
          path="/settings"
          element={
            <ProtectedRoute allowedRoles={["ADMIN"]}>
              <Settings />
            </ProtectedRoute>
          }
        />
        <Route path="/profile" element={<Profile />} />
      </Route>

      <Route path="/" element={<Navigate to="/dashboard" replace />} />
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}
