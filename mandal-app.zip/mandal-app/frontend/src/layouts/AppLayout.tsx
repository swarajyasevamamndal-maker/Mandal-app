import { LogOut, Menu, Moon, Sun, X } from "lucide-react";
import { useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useLanguage } from "../context/LanguageContext";
import { useTheme } from "../context/ThemeContext";
import { mobilePrimaryKeys, visibleNavItems } from "../routes/navItems";
import { useBranding } from "../context/BrandingContext";

export default function AppLayout() {
  const { user, logout, hasRole } = useAuth();
  const { t, language, toggleLanguage } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const { mandalName, logoUrl } = useBranding();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  if (!user) return null;

  const items = visibleNavItems(user.role);
  const mobileItems = items.filter((i) => mobilePrimaryKeys.includes(i.labelKey));

  return (
    <div className="min-h-screen bg-cream dark:bg-ink flex">
      {/* Desktop sidebar */}
      <aside className="hidden md:flex md:flex-col w-64 shrink-0 border-r border-marigold-100/60 dark:border-white/5 bg-white dark:bg-ink-800 px-4 py-6">
        <div className="flex items-center gap-2 px-2 mb-8">
          {logoUrl ? (
            <img src={logoUrl} alt={mandalName} className="h-9 w-9 rounded-full object-cover" />
          ) : (
            <div className="h-9 w-9 rounded-full bg-gradient-to-br from-marigold-400 to-maroon-600" />
          )}
          <span className="font-display font-semibold text-maroon-700 dark:text-marigold-300 text-lg">
            {mandalName}
          </span>
        </div>
        <nav className="flex-1 space-y-1">
          {items.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition ${
                  isActive
                    ? "bg-maroon-600 text-white"
                    : "text-ink/70 dark:text-cream-100/70 hover:bg-marigold-50 dark:hover:bg-white/5"
                }`
              }
            >
              <item.icon size={18} />
              {t.nav[item.labelKey]}
            </NavLink>
          ))}
        </nav>
        <button
          onClick={logout}
          className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-maroon-600 dark:text-marigold-300 hover:bg-marigold-50 dark:hover:bg-white/5"
        >
          <LogOut size={18} /> {t.nav.logout}
        </button>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="h-14 flex items-center justify-between px-4 border-b border-marigold-100/60 dark:border-white/5 bg-white/80 dark:bg-ink-800/80 backdrop-blur sticky top-0 z-30">
          <button
            className="md:hidden text-maroon-700 dark:text-marigold-300"
            onClick={() => setMobileMenuOpen(true)}
            aria-label="Open menu"
          >
            <Menu size={22} />
          </button>
          <span className="md:hidden font-display font-semibold text-maroon-700 dark:text-marigold-300">
            {mandalName}
          </span>

          <div className="flex items-center gap-2 ml-auto">
            <button
              onClick={toggleLanguage}
              className="h-8 px-2.5 rounded-full bg-marigold-50 dark:bg-white/5 text-xs font-medium text-maroon-700 dark:text-marigold-300"
            >
              {language === "mr" ? "EN" : "मर"}
            </button>
            <button
              onClick={toggleTheme}
              className="h-8 w-8 rounded-full bg-marigold-50 dark:bg-white/5 flex items-center justify-center text-maroon-700 dark:text-marigold-300"
              aria-label="Toggle dark mode"
            >
              {theme === "light" ? <Moon size={14} /> : <Sun size={14} />}
            </button>
            <button
              onClick={() => navigate("/profile")}
              className="h-8 w-8 rounded-full bg-maroon-600 text-white text-xs font-semibold flex items-center justify-center"
              aria-label="Profile"
            >
              {user.name.charAt(0).toUpperCase()}
            </button>
          </div>
        </header>

        {/* Mobile slide-in menu */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-40 md:hidden">
            <div className="absolute inset-0 bg-ink/50" onClick={() => setMobileMenuOpen(false)} />
            <div className="absolute left-0 top-0 bottom-0 w-72 bg-white dark:bg-ink-800 p-4 shadow-elevated animate-[slideIn_0.2s_ease-out]">
              <div className="flex items-center justify-between mb-6">
                <span className="font-display font-semibold text-maroon-700 dark:text-marigold-300">
                  {mandalName}
                </span>
                <button onClick={() => setMobileMenuOpen(false)} aria-label="Close menu">
                  <X size={20} />
                </button>
              </div>
              <nav className="space-y-1">
                {items.map((item) => (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    onClick={() => setMobileMenuOpen(false)}
                    className={({ isActive }) =>
                      `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium ${
                        isActive
                          ? "bg-maroon-600 text-white"
                          : "text-ink/70 dark:text-cream-100/70"
                      }`
                    }
                  >
                    <item.icon size={18} />
                    {t.nav[item.labelKey]}
                  </NavLink>
                ))}
                <button
                  onClick={logout}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-maroon-600 dark:text-marigold-300"
                >
                  <LogOut size={18} /> {t.nav.logout}
                </button>
              </nav>
            </div>
          </div>
        )}

        <main className="flex-1 px-4 py-5 md:px-8 md:py-8 pb-24 md:pb-8">
          <Outlet />
        </main>
      </div>

      {/* Mobile bottom nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white dark:bg-ink-800 border-t border-marigold-100/60 dark:border-white/5 flex justify-around py-2">
        {mobileItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              `flex flex-col items-center gap-0.5 px-2 py-1 text-[11px] font-medium ${
                isActive ? "text-maroon-600 dark:text-marigold-300" : "text-ink/40 dark:text-cream-100/40"
              }`
            }
          >
            <item.icon size={20} />
            {t.nav[item.labelKey]}
          </NavLink>
        ))}
        {hasRole("ADMIN") && (
          <NavLink
            to="/settings"
            className={({ isActive }) =>
              `flex flex-col items-center gap-0.5 px-2 py-1 text-[11px] font-medium ${
                isActive ? "text-maroon-600 dark:text-marigold-300" : "text-ink/40 dark:text-cream-100/40"
              }`
            }
          >
            <Menu size={20} />
            {t.nav.settings}
          </NavLink>
        )}
      </nav>
    </div>
  );
}
