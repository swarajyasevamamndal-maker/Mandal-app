export type Role = "ADMIN" | "TREASURER" | "MEMBER";

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string | null;
  role: Role;
  isActive: boolean;
}

export interface Expense {
  id: string;
  date: string;
  categoryId: string;
  category: { id: string; nameMr: string; nameEn: string };
  description: string;
  amount: number;
  paymentMethod: "CASH" | "UPI" | "BANK_TRANSFER" | "OTHER";
  paidById?: string | null;
  paidBy?: { id: string; name: string } | null;
  vendorName?: string | null;
  billNumber?: string | null;
  billPhotoUrl?: string | null;
  eventId?: string | null;
  notes?: string | null;
  createdAt: string;
}

export interface Donation {
  id: string;
  date: string;
  donorName: string;
  donorMobile?: string | null;
  amount: number;
  paymentMethod: "CASH" | "UPI" | "BANK_TRANSFER" | "OTHER";
  upiTxnRefId?: string | null;
  receiptNumber: string;
  purpose?: string | null;
  notes?: string | null;
  createdAt: string;
}

export interface UpiTransaction {
  id: string;
  utrNumber: string;
  date: string;
  time: string;
  senderName?: string | null;
  receiverName?: string | null;
  amount: number;
  type: "INCOME" | "EXPENSE";
  upiApp: string;
  status: "SUCCESS" | "PENDING" | "FAILED";
  screenshotUrl?: string | null;
  notes?: string | null;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}

export interface DashboardSummary {
  totalIncome: number;
  totalExpenses: number;
  currentBalance: number;
  cashBalance: number;
  upiBalance: number;
  bankBalance: number;
  totalDonations: number;
  memberCount: number;
  recentExpenses: {
    id: string;
    description: string;
    category: string;
    amount: number;
    date: string;
    paymentMethod: string;
  }[];
  recentDonations: {
    id: string;
    donorName: string;
    amount: number;
    date: string;
    receiptNumber: string;
  }[];
  monthly: { month: string; income: number; expense: number }[];
}
