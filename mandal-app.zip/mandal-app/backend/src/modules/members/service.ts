import { prisma } from "../../config/db";
import { AppError } from "../../middleware/errorHandler";
import { writeAuditLog } from "../../utils/audit";
import { createMemberSchema, updateMemberSchema } from "./validation";

export async function listMembers(search?: string) {
  return prisma.member.findMany({
    where: {
      deletedAt: null,
      ...(search
        ? {
            OR: [
              { name: { contains: search, mode: "insensitive" as const } },
              { mobile: { contains: search, mode: "insensitive" as const } },
            ],
          }
        : {}),
    },
    orderBy: { name: "asc" },
  });
}

export async function getMember(id: string) {
  const member = await prisma.member.findFirst({ where: { id, deletedAt: null } });
  if (!member) throw new AppError("Member not found", 404);
  return member;
}

export async function createMember(input: unknown, userId: string) {
  const data = createMemberSchema.parse(input);

  const member = await prisma.member.create({
    data: {
      name: data.name,
      mobile: data.mobile,
      email: data.email || undefined,
      address: data.address,
      joiningDate: data.joiningDate,
    },
  });

  await writeAuditLog({ userId, action: "CREATE", tableName: "members", recordId: member.id, newValue: member });
  return member;
}

export async function updateMember(id: string, input: unknown, userId: string) {
  const data = updateMemberSchema.parse(input);
  const existing = await prisma.member.findFirst({ where: { id, deletedAt: null } });
  if (!existing) throw new AppError("Member not found", 404);

  const updated = await prisma.member.update({
    where: { id },
    data: {
      ...(data.name ? { name: data.name } : {}),
      ...(data.mobile ? { mobile: data.mobile } : {}),
      ...(data.email !== undefined ? { email: data.email || null } : {}),
      ...(data.address !== undefined ? { address: data.address } : {}),
      ...(data.photoUrl !== undefined ? { photoUrl: data.photoUrl } : {}),
      ...(data.status ? { status: data.status } : {}),
    },
  });

  await writeAuditLog({ userId, action: "UPDATE", tableName: "members", recordId: id, oldValue: existing, newValue: updated });
  return updated;
}

export async function deleteMember(id: string, userId: string) {
  const existing = await prisma.member.findFirst({ where: { id, deletedAt: null } });
  if (!existing) throw new AppError("Member not found", 404);

  const deleted = await prisma.member.update({ where: { id }, data: { deletedAt: new Date() } });
  await writeAuditLog({ userId, action: "DELETE", tableName: "members", recordId: id, oldValue: existing, newValue: deleted });
}
