import { z } from "zod";

export const createMemberSchema = z.object({
  name: z.string().min(2, "नाव आवश्यक आहे"),
  mobile: z.string().regex(/^[0-9]{10}$/, "Mobile number 10 digits असावा"),
  email: z.string().email().optional().or(z.literal("")),
  address: z.string().optional(),
  joiningDate: z.coerce.date().optional(),
});

export const updateMemberSchema = z.object({
  name: z.string().min(2).optional(),
  mobile: z.string().regex(/^[0-9]{10}$/).optional(),
  email: z.string().email().optional().or(z.literal("")),
  address: z.string().optional(),
  photoUrl: z.string().optional(),
  status: z.enum(["active", "inactive"]).optional(),
});
