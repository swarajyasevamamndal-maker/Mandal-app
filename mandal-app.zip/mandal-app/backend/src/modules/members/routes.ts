import { NextFunction, Request, Response, Router } from "express";
import { requireAuth } from "../../middleware/auth";
import { requireRole } from "../../middleware/role";
import { upload } from "../../middleware/upload";
import * as memberService from "./service";

export const memberRouter = Router();

memberRouter.use(requireAuth);

memberRouter.get("/", async (req: Request, res: Response, next: NextFunction) => {
  try {
    res.json(await memberService.listMembers(req.query.search as string | undefined));
  } catch (err) {
    next(err);
  }
});

memberRouter.get("/:id", async (req: Request, res: Response, next: NextFunction) => {
  try {
    res.json(await memberService.getMember(req.params.id));
  } catch (err) {
    next(err);
  }
});

memberRouter.post(
  "/",
  requireRole("ADMIN"),
  upload.single("photo"),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const body = { ...req.body, photoUrl: req.file ? `/uploads/${req.file.filename}` : undefined };
      res.status(201).json(await memberService.createMember(body, req.user!.id));
    } catch (err) {
      next(err);
    }
  }
);

memberRouter.put(
  "/:id",
  requireRole("ADMIN"),
  upload.single("photo"),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const body = { ...req.body, ...(req.file ? { photoUrl: `/uploads/${req.file.filename}` } : {}) };
      res.json(await memberService.updateMember(req.params.id, body, req.user!.id));
    } catch (err) {
      next(err);
    }
  }
);

memberRouter.delete("/:id", requireRole("ADMIN"), async (req: Request, res: Response, next: NextFunction) => {
  try {
    await memberService.deleteMember(req.params.id, req.user!.id);
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});
