import { prisma } from "../../config/db";

async function sumPaise(model: "expense" | "donation", where: Record<string, unknown> = {}) {
  const result = await (prisma[model] as any).aggregate({
    _sum: { amountPaise: true },
    where: { deletedAt: null, ...where },
  });
  return BigInt(result._sum.amountPaise ?? 0);
}

/**
 * Total Income here means Donations, since donations are the mandal's
 * income source (per the app's field/module design — there's no
 * separate "income" table beyond donations).
 */
export async function getDashboardSummary() {
  const [
    totalDonations,
    totalExpenses,
    cashDonations,
    cashExpenses,
    upiDonations,
    upiExpenses,
    bankDonations,
    bankExpenses,
    memberCount,
    recentExpenses,
    recentDonations,
    monthlyRows,
  ] = await Promise.all([
    sumPaise("donation"),
    sumPaise("expense"),
    sumPaise("donation", { paymentMethod: "CASH" }),
    sumPaise("expense", { paymentMethod: "CASH" }),
    sumPaise("donation", { paymentMethod: "UPI" }),
    sumPaise("expense", { paymentMethod: "UPI" }),
    sumPaise("donation", { paymentMethod: "BANK_TRANSFER" }),
    sumPaise("expense", { paymentMethod: "BANK_TRANSFER" }),
    prisma.member.count({ where: { deletedAt: null, status: "active" } }),
    prisma.expense.findMany({
      where: { deletedAt: null },
      orderBy: { date: "desc" },
      take: 5,
      include: { category: true },
    }),
    prisma.donation.findMany({
      where: { deletedAt: null },
      orderBy: { date: "desc" },
      take: 5,
    }),
    monthlyTotals(),
  ]);

  const toRupees = (p: bigint) => Number(p) / 100;

  return {
    totalIncome: toRupees(totalDonations),
    totalExpenses: toRupees(totalExpenses),
    currentBalance: toRupees(totalDonations - totalExpenses),
    cashBalance: toRupees(cashDonations - cashExpenses),
    upiBalance: toRupees(upiDonations - upiExpenses),
    bankBalance: toRupees(bankDonations - bankExpenses),
    totalDonations: toRupees(totalDonations),
    memberCount,
    recentExpenses: recentExpenses.map((e) => ({
      id: e.id,
      description: e.description,
      category: e.category.nameMr,
      amount: toRupees(e.amountPaise),
      date: e.date,
      paymentMethod: e.paymentMethod,
    })),
    recentDonations: recentDonations.map((d) => ({
      id: d.id,
      donorName: d.donorName,
      amount: toRupees(d.amountPaise),
      date: d.date,
      receiptNumber: d.receiptNumber,
    })),
    monthly: monthlyRows,
  };
}

/**
 * Last 6 months of income vs expense, grouped in JS since amounts are
 * BigInt and cross-DB date-truncation SQL is awkward via Prisma's
 * query builder for a simple aggregate like this.
 */
async function monthlyTotals() {
  const sixMonthsAgo = new Date();
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 5);
  sixMonthsAgo.setDate(1);

  const [expenses, donations] = await Promise.all([
    prisma.expense.findMany({
      where: { deletedAt: null, date: { gte: sixMonthsAgo } },
      select: { date: true, amountPaise: true },
    }),
    prisma.donation.findMany({
      where: { deletedAt: null, date: { gte: sixMonthsAgo } },
      select: { date: true, amountPaise: true },
    }),
  ]);

  const buckets = new Map<string, { income: number; expense: number }>();
  for (let i = 0; i < 6; i++) {
    const d = new Date(sixMonthsAgo);
    d.setMonth(d.getMonth() + i);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    buckets.set(key, { income: 0, expense: 0 });
  }

  const keyOf = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;

  for (const e of expenses) {
    const key = keyOf(e.date);
    const bucket = buckets.get(key);
    if (bucket) bucket.expense += Number(e.amountPaise) / 100;
  }
  for (const d of donations) {
    const key = keyOf(d.date);
    const bucket = buckets.get(key);
    if (bucket) bucket.income += Number(d.amountPaise) / 100;
  }

  return Array.from(buckets.entries()).map(([month, totals]) => ({ month, ...totals }));
}
