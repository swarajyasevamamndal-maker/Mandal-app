import { NextFunction, Request, Response, Router } from "express";
import { requireAuth } from "../../middleware/auth";
import { getDashboardSummary } from "./service";

export const dashboardRouter = Router();

dashboardRouter.use(requireAuth);

dashboardRouter.get("/summary", async (_req: Request, res: Response, next: NextFunction) => {
  try {
    res.json(await getDashboardSummary());
  } catch (err) {
    next(err);
  }
});
