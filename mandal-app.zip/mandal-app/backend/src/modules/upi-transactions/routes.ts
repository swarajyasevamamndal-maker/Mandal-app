import { Router } from "express";
import { requireAuth } from "../../middleware/auth";
import { requireRole } from "../../middleware/role";
import { upload } from "../../middleware/upload";
import { checkDuplicate, create, getOne, list, remove, update } from "./controller";

export const upiTransactionRouter = Router();

upiTransactionRouter.use(requireAuth);

upiTransactionRouter.get("/", list);
upiTransactionRouter.get("/check-duplicate", checkDuplicate);
upiTransactionRouter.get("/:id", getOne);

upiTransactionRouter.post(
  "/",
  requireRole("ADMIN", "TREASURER"),
  upload.single("screenshot"),
  create
);
upiTransactionRouter.put(
  "/:id",
  requireRole("ADMIN", "TREASURER"),
  upload.single("screenshot"),
  update
);
upiTransactionRouter.delete("/:id", requireRole("ADMIN"), remove);
