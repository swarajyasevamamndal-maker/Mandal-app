import { NextFunction, Request, Response } from "express";
import * as upiService from "./service";

export async function list(req: Request, res: Response, next: NextFunction) {
  try {
    res.json(await upiService.listUpiTransactions(req.query));
  } catch (err) {
    next(err);
  }
}

export async function getOne(req: Request, res: Response, next: NextFunction) {
  try {
    res.json(await upiService.getUpiTransaction(req.params.id));
  } catch (err) {
    next(err);
  }
}

// Lets the Add-Transaction form check a UTR before submitting, so the
// user sees "duplicate" instantly instead of after a failed save.
export async function checkDuplicate(req: Request, res: Response, next: NextFunction) {
  try {
    const utr = String(req.query.utr || "");
    res.json(await upiService.checkDuplicateUtr(utr));
  } catch (err) {
    next(err);
  }
}

export async function create(req: Request, res: Response, next: NextFunction) {
  try {
    const body = { ...req.body, screenshotUrl: req.file ? `/uploads/${req.file.filename}` : req.body.screenshotUrl };
    const txn = await upiService.createUpiTransaction(body, req.user!.id);
    res.status(201).json(txn);
  } catch (err) {
    next(err);
  }
}

export async function update(req: Request, res: Response, next: NextFunction) {
  try {
    const body = { ...req.body, ...(req.file ? { screenshotUrl: `/uploads/${req.file.filename}` } : {}) };
    const txn = await upiService.updateUpiTransaction(req.params.id, body, req.user!.id);
    res.json(txn);
  } catch (err) {
    next(err);
  }
}

export async function remove(req: Request, res: Response, next: NextFunction) {
  try {
    await upiService.deleteUpiTransaction(req.params.id, req.user!.id);
    res.status(204).send();
  } catch (err) {
    next(err);
  }
}
