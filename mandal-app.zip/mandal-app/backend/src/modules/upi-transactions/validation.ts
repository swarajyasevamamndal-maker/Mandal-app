import { z } from "zod";

export const upiTxnTypeEnum = z.enum(["INCOME", "EXPENSE"]);
export const upiStatusEnum = z.enum(["SUCCESS", "PENDING", "FAILED"]);

export const createUpiTxnSchema = z.object({
  utrNumber: z.string().min(4, "UTR / Transaction ID is required"),
  date: z.coerce.date(),
  time: z.string().min(1, "Time is required"), // e.g. "14:32"
  senderName: z.string().optional(),
  receiverName: z.string().optional(),
  amount: z.coerce.number().positive("Amount must be greater than 0"),
  type: upiTxnTypeEnum,
  upiApp: z.enum(["Google Pay", "PhonePe", "Paytm", "Bank UPI", "Other"]),
  status: upiStatusEnum.default("SUCCESS"),
  screenshotUrl: z.string().optional(),
  notes: z.string().optional(),
  linkedExpenseId: z.string().uuid().optional(),
  linkedDonationId: z.string().uuid().optional(),
});

export const updateUpiTxnSchema = createUpiTxnSchema.partial();

export const upiTxnFilterSchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
  dateFrom: z.coerce.date().optional(),
  dateTo: z.coerce.date().optional(),
  type: upiTxnTypeEnum.optional(),
  status: upiStatusEnum.optional(),
  upiApp: z.string().optional(),
  search: z.string().optional(), // matches UTR, sender, receiver
  sortBy: z.enum(["date", "amount"]).default("date"),
  sortOrder: z.enum(["asc", "desc"]).default("desc"),
});
