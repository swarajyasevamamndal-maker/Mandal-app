import { prisma } from "../../config/db";
import { AppError } from "../../middleware/errorHandler";
import { rupeesToPaise } from "../../utils/currency";
import { writeAuditLog } from "../../utils/audit";
import {
  createUpiTxnSchema,
  upiTxnFilterSchema,
  updateUpiTxnSchema,
} from "./validation";

export async function listUpiTransactions(query: unknown) {
  const filters = upiTxnFilterSchema.parse(query);

  const where = {
    ...(filters.type ? { type: filters.type } : {}),
    ...(filters.status ? { status: filters.status } : {}),
    ...(filters.upiApp ? { upiApp: filters.upiApp } : {}),
    ...(filters.dateFrom || filters.dateTo
      ? {
          date: {
            ...(filters.dateFrom ? { gte: filters.dateFrom } : {}),
            ...(filters.dateTo ? { lte: filters.dateTo } : {}),
          },
        }
      : {}),
    ...(filters.search
      ? {
          OR: [
            { utrNumber: { contains: filters.search, mode: "insensitive" as const } },
            { senderName: { contains: filters.search, mode: "insensitive" as const } },
            { receiverName: { contains: filters.search, mode: "insensitive" as const } },
          ],
        }
      : {}),
  };

  const sortField = filters.sortBy === "amount" ? "amountPaise" : filters.sortBy;

  const [items, total] = await Promise.all([
    prisma.upiTransaction.findMany({
      where,
      orderBy: { [sortField]: filters.sortOrder },
      skip: (filters.page - 1) * filters.pageSize,
      take: filters.pageSize,
    }),
    prisma.upiTransaction.count({ where }),
  ]);

  return {
    items: items.map(serializeTxn),
    total,
    page: filters.page,
    pageSize: filters.pageSize,
  };
}

export async function getUpiTransaction(id: string) {
  const txn = await prisma.upiTransaction.findUnique({ where: { id } });
  if (!txn) throw new AppError("UPI transaction not found", 404);
  return serializeTxn(txn);
}

export async function checkDuplicateUtr(utrNumber: string) {
  const existing = await prisma.upiTransaction.findUnique({ where: { utrNumber } });
  return { isDuplicate: !!existing, existing: existing ? serializeTxn(existing) : null };
}

export async function createUpiTransaction(input: unknown, userId: string) {
  const data = createUpiTxnSchema.parse(input);

  // Explicit pre-check gives a clear, friendly error message; the DB's
  // unique constraint on utrNumber remains the hard guarantee in case
  // of a race condition (caught by errorHandler as a P2002 fallback).
  const existing = await prisma.upiTransaction.findUnique({ where: { utrNumber: data.utrNumber } });
  if (existing) {
    throw new AppError(
      `हा UTR/Transaction ID (${data.utrNumber}) आधीच नोंदवलेला आहे — duplicate UPI transaction`,
      409
    );
  }

  const txn = await prisma.upiTransaction.create({
    data: {
      utrNumber: data.utrNumber,
      date: data.date,
      time: data.time,
      senderName: data.senderName,
      receiverName: data.receiverName,
      amountPaise: rupeesToPaise(data.amount),
      type: data.type,
      upiApp: data.upiApp,
      status: data.status,
      screenshotUrl: data.screenshotUrl,
      notes: data.notes,
      linkedExpenseId: data.linkedExpenseId,
      linkedDonationId: data.linkedDonationId,
    },
  });

  await writeAuditLog({
    userId,
    action: "CREATE",
    tableName: "upi_transactions",
    recordId: txn.id,
    newValue: txn,
  });

  return serializeTxn(txn);
}

export async function updateUpiTransaction(id: string, input: unknown, userId: string) {
  const data = updateUpiTxnSchema.parse(input);

  const existing = await prisma.upiTransaction.findUnique({ where: { id } });
  if (!existing) throw new AppError("UPI transaction not found", 404);

  if (data.utrNumber && data.utrNumber !== existing.utrNumber) {
    const clash = await prisma.upiTransaction.findUnique({ where: { utrNumber: data.utrNumber } });
    if (clash) {
      throw new AppError(
        `हा UTR/Transaction ID (${data.utrNumber}) आधीच नोंदवलेला आहे — duplicate UPI transaction`,
        409
      );
    }
  }

  const updated = await prisma.upiTransaction.update({
    where: { id },
    data: {
      ...(data.utrNumber ? { utrNumber: data.utrNumber } : {}),
      ...(data.date ? { date: data.date } : {}),
      ...(data.time ? { time: data.time } : {}),
      ...(data.senderName !== undefined ? { senderName: data.senderName } : {}),
      ...(data.receiverName !== undefined ? { receiverName: data.receiverName } : {}),
      ...(data.amount !== undefined ? { amountPaise: rupeesToPaise(data.amount) } : {}),
      ...(data.type ? { type: data.type } : {}),
      ...(data.upiApp ? { upiApp: data.upiApp } : {}),
      ...(data.status ? { status: data.status } : {}),
      ...(data.screenshotUrl !== undefined ? { screenshotUrl: data.screenshotUrl } : {}),
      ...(data.notes !== undefined ? { notes: data.notes } : {}),
      ...(data.linkedExpenseId !== undefined ? { linkedExpenseId: data.linkedExpenseId } : {}),
      ...(data.linkedDonationId !== undefined ? { linkedDonationId: data.linkedDonationId } : {}),
    },
  });

  await writeAuditLog({
    userId,
    action: "UPDATE",
    tableName: "upi_transactions",
    recordId: id,
    oldValue: existing,
    newValue: updated,
  });

  return serializeTxn(updated);
}

export async function deleteUpiTransaction(id: string, userId: string) {
  const existing = await prisma.upiTransaction.findUnique({ where: { id } });
  if (!existing) throw new AppError("UPI transaction not found", 404);

  // UPI transactions have no soft-delete column in the schema (they are
  // reference/reconciliation records, not primary ledger entries like
  // expenses/donations) — deletion is hard, but still fully audited.
  await prisma.upiTransaction.delete({ where: { id } });

  await writeAuditLog({
    userId,
    action: "DELETE",
    tableName: "upi_transactions",
    recordId: id,
    oldValue: existing,
  });
}

function serializeTxn<T extends { amountPaise: bigint }>(txn: T) {
  return {
    ...txn,
    amountPaise: undefined,
    amount: Number(txn.amountPaise) / 100,
  };
}
