import { prisma } from "../../config/db";
import { AppError } from "../../middleware/errorHandler";
import { writeAuditLog } from "../../utils/audit";
import { createCategorySchema, updateCategorySchema } from "./validation";

export async function listCategories(includeInactive: boolean) {
  return prisma.category.findMany({
    where: includeInactive ? {} : { isActive: true },
    orderBy: [{ sortOrder: "asc" }, { nameEn: "asc" }],
  });
}

export async function createCategory(input: unknown, userId: string) {
  const data = createCategorySchema.parse(input);

  const category = await prisma.category.create({ data });

  await writeAuditLog({
    userId,
    action: "CREATE",
    tableName: "categories",
    recordId: category.id,
    newValue: category,
  });

  return category;
}

export async function updateCategory(id: string, input: unknown, userId: string) {
  const data = updateCategorySchema.parse(input);

  const existing = await prisma.category.findUnique({ where: { id } });
  if (!existing) throw new AppError("Category not found", 404);

  const updated = await prisma.category.update({ where: { id }, data });

  await writeAuditLog({
    userId,
    action: "UPDATE",
    tableName: "categories",
    recordId: id,
    oldValue: existing,
    newValue: updated,
  });

  return updated;
}

/**
 * Categories already used on expenses are never hard-deleted — the
 * expense.categoryId foreign key would break historical records.
 * Deactivating hides it from new-expense dropdowns while keeping past
 * reports intact.
 */
export async function deactivateCategory(id: string, userId: string) {
  const existing = await prisma.category.findUnique({ where: { id } });
  if (!existing) throw new AppError("Category not found", 404);

  const updated = await prisma.category.update({ where: { id }, data: { isActive: false } });

  await writeAuditLog({
    userId,
    action: "UPDATE",
    tableName: "categories",
    recordId: id,
    oldValue: existing,
    newValue: updated,
  });

  return updated;
}
