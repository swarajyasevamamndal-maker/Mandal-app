import { z } from "zod";

export const createCategorySchema = z.object({
  nameMr: z.string().min(1, "मराठी नाव आवश्यक आहे"),
  nameEn: z.string().min(1, "English name is required"),
  type: z.enum(["expense", "income"]).default("expense"),
  sortOrder: z.number().int().optional(),
});

export const updateCategorySchema = z.object({
  nameMr: z.string().min(1).optional(),
  nameEn: z.string().min(1).optional(),
  sortOrder: z.number().int().optional(),
  isActive: z.boolean().optional(),
});
