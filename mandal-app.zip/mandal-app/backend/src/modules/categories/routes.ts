import { NextFunction, Request, Response, Router } from "express";
import { requireAuth } from "../../middleware/auth";
import { requireRole } from "../../middleware/role";
import * as categoryService from "./service";

export const categoryRouter = Router();

categoryRouter.use(requireAuth);

// Everyone can list active categories; pass ?includeInactive=true to
// see all — used both by the admin Settings screen and by the Expense
// edit form (so editing an expense whose category was later
// deactivated still shows its correct category instead of losing it).
categoryRouter.get("/", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const includeInactive = req.query.includeInactive === "true";
    res.json(await categoryService.listCategories(includeInactive));
  } catch (err) {
    next(err);
  }
});

categoryRouter.post("/", requireRole("ADMIN"), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const category = await categoryService.createCategory(req.body, req.user!.id);
    res.status(201).json(category);
  } catch (err) {
    next(err);
  }
});

categoryRouter.put("/:id", requireRole("ADMIN"), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const category = await categoryService.updateCategory(req.params.id, req.body, req.user!.id);
    res.json(category);
  } catch (err) {
    next(err);
  }
});

// Soft "delete" — deactivates instead of removing, per requirement.
categoryRouter.delete("/:id", requireRole("ADMIN"), async (req: Request, res: Response, next: NextFunction) => {
  try {
    await categoryService.deactivateCategory(req.params.id, req.user!.id);
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});
