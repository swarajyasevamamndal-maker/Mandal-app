import { NextFunction, Request, Response } from "express";
import * as donationService from "./service";
import { generateReceiptPdf } from "../../utils/receiptPdf";
import { prisma } from "../../config/db";
import { AppError } from "../../middleware/errorHandler";

export async function list(req: Request, res: Response, next: NextFunction) {
  try {
    res.json(await donationService.listDonations(req.query));
  } catch (err) {
    next(err);
  }
}

export async function getOne(req: Request, res: Response, next: NextFunction) {
  try {
    res.json(await donationService.getDonation(req.params.id));
  } catch (err) {
    next(err);
  }
}

export async function create(req: Request, res: Response, next: NextFunction) {
  try {
    const donation = await donationService.createDonation(req.body, req.user!.id);
    res.status(201).json(donation);
  } catch (err) {
    next(err);
  }
}

export async function update(req: Request, res: Response, next: NextFunction) {
  try {
    const donation = await donationService.updateDonation(req.params.id, req.body, req.user!.id);
    res.json(donation);
  } catch (err) {
    next(err);
  }
}

export async function remove(req: Request, res: Response, next: NextFunction) {
  try {
    await donationService.deleteDonation(req.params.id, req.user!.id);
    res.status(204).send();
  } catch (err) {
    next(err);
  }
}

export async function downloadReceipt(req: Request, res: Response, next: NextFunction) {
  try {
    const donation = await prisma.donation.findFirst({
      where: { id: req.params.id, deletedAt: null },
    });
    if (!donation) throw new AppError("Donation not found", 404);

    const settings = await prisma.settings.findFirst();
    const authorizedPerson = req.user!.email; // signer identity for the audit trail

    const pdfBytes = await generateReceiptPdf({
      mandalName: settings?.mandalName || "देवी मंडळ",
      deviName: settings?.deviName || "श्री देवी",
      logoUrl: settings?.logoUrl || undefined,
      deviPhotoUrl: settings?.deviPhotoUrl || undefined,
      donorName: donation.donorName,
      date: donation.date,
      receiptNumber: donation.receiptNumber,
      amountPaise: donation.amountPaise,
      paymentMethod: donation.paymentMethod,
      utrNumber: donation.upiTxnRefId || undefined,
      authorizedPerson,
    });

    res.setHeader("Content-Type", "application/pdf");
    res.setHeader(
      "Content-Disposition",
      `inline; filename="receipt-${donation.receiptNumber}.pdf"`
    );
    res.send(Buffer.from(pdfBytes));
  } catch (err) {
    next(err);
  }
}
