import { z } from "zod";

export const paymentMethodEnum = z.enum(["CASH", "UPI", "BANK_TRANSFER", "OTHER"]);

export const createDonationSchema = z.object({
  date: z.coerce.date(),
  donorName: z.string().min(2, "Donor name is required"),
  donorMobile: z
    .string()
    .regex(/^[0-9]{10}$/, "Mobile number must be 10 digits")
    .optional()
    .or(z.literal("")),
  amount: z.coerce.number().positive("Donation amount must be greater than 0"),
  paymentMethod: paymentMethodEnum,
  upiTxnRefId: z.string().optional(),
  // Receipt number is optional on input — auto-generated when not given.
  receiptNumber: z.string().optional(),
  purpose: z.string().optional(),
  notes: z.string().optional(),
});

export const updateDonationSchema = createDonationSchema.partial();

export const donationFilterSchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
  dateFrom: z.coerce.date().optional(),
  dateTo: z.coerce.date().optional(),
  paymentMethod: paymentMethodEnum.optional(),
  search: z.string().optional(), // matches donor name, mobile, receipt number
  sortBy: z.enum(["date", "amount", "donorName"]).default("date"),
  sortOrder: z.enum(["asc", "desc"]).default("desc"),
});
