import { Router } from "express";
import { requireAuth } from "../../middleware/auth";
import { requireRole } from "../../middleware/role";
import { create, downloadReceipt, getOne, list, remove, update } from "./controller";

export const donationRouter = Router();

donationRouter.use(requireAuth);

donationRouter.get("/", list);
donationRouter.get("/:id", getOne);
donationRouter.get("/:id/receipt", downloadReceipt);

donationRouter.post("/", requireRole("ADMIN", "TREASURER"), create);
donationRouter.put("/:id", requireRole("ADMIN", "TREASURER"), update);
donationRouter.delete("/:id", requireRole("ADMIN"), remove);
