import { prisma } from "../../config/db";
import { AppError } from "../../middleware/errorHandler";
import { rupeesToPaise } from "../../utils/currency";
import { writeAuditLog } from "../../utils/audit";
import { generateReceiptNumber } from "../../utils/receiptNumber";
import {
  createDonationSchema,
  donationFilterSchema,
  updateDonationSchema,
} from "./validation";

export async function listDonations(query: unknown) {
  const filters = donationFilterSchema.parse(query);

  const where = {
    deletedAt: null,
    ...(filters.paymentMethod ? { paymentMethod: filters.paymentMethod } : {}),
    ...(filters.dateFrom || filters.dateTo
      ? {
          date: {
            ...(filters.dateFrom ? { gte: filters.dateFrom } : {}),
            ...(filters.dateTo ? { lte: filters.dateTo } : {}),
          },
        }
      : {}),
    ...(filters.search
      ? {
          OR: [
            { donorName: { contains: filters.search, mode: "insensitive" as const } },
            { donorMobile: { contains: filters.search, mode: "insensitive" as const } },
            { receiptNumber: { contains: filters.search, mode: "insensitive" as const } },
          ],
        }
      : {}),
  };

  const sortField = filters.sortBy === "amount" ? "amountPaise" : filters.sortBy;

  const [items, total] = await Promise.all([
    prisma.donation.findMany({
      where,
      orderBy: { [sortField]: filters.sortOrder },
      skip: (filters.page - 1) * filters.pageSize,
      take: filters.pageSize,
    }),
    prisma.donation.count({ where }),
  ]);

  return {
    items: items.map(serializeDonation),
    total,
    page: filters.page,
    pageSize: filters.pageSize,
  };
}

export async function getDonation(id: string) {
  const donation = await prisma.donation.findFirst({ where: { id, deletedAt: null } });
  if (!donation) throw new AppError("Donation not found", 404);
  return serializeDonation(donation);
}

export async function createDonation(input: unknown, userId: string) {
  const data = createDonationSchema.parse(input);

  const receiptNumber = data.receiptNumber?.trim() || (await generateReceiptNumber());

  // Guard against a manually-supplied receipt number colliding with an
  // existing one, with a clear message instead of a raw DB error.
  if (data.receiptNumber) {
    const existing = await prisma.donation.findUnique({ where: { receiptNumber } });
    if (existing) {
      throw new AppError(`Receipt number "${receiptNumber}" is already in use`, 409);
    }
  }

  const donation = await prisma.donation.create({
    data: {
      date: data.date,
      donorName: data.donorName,
      donorMobile: data.donorMobile || undefined,
      amountPaise: rupeesToPaise(data.amount),
      paymentMethod: data.paymentMethod,
      upiTxnRefId: data.upiTxnRefId,
      receiptNumber,
      purpose: data.purpose,
      notes: data.notes,
      createdById: userId,
    },
  });

  await writeAuditLog({
    userId,
    action: "CREATE",
    tableName: "donations",
    recordId: donation.id,
    newValue: donation,
  });

  return serializeDonation(donation);
}

export async function updateDonation(id: string, input: unknown, userId: string) {
  const data = updateDonationSchema.parse(input);

  const existing = await prisma.donation.findFirst({ where: { id, deletedAt: null } });
  if (!existing) throw new AppError("Donation not found", 404);

  if (data.receiptNumber && data.receiptNumber !== existing.receiptNumber) {
    const clash = await prisma.donation.findUnique({ where: { receiptNumber: data.receiptNumber } });
    if (clash) throw new AppError(`Receipt number "${data.receiptNumber}" is already in use`, 409);
  }

  const updated = await prisma.donation.update({
    where: { id },
    data: {
      ...(data.date ? { date: data.date } : {}),
      ...(data.donorName ? { donorName: data.donorName } : {}),
      ...(data.donorMobile !== undefined ? { donorMobile: data.donorMobile || null } : {}),
      ...(data.amount !== undefined ? { amountPaise: rupeesToPaise(data.amount) } : {}),
      ...(data.paymentMethod ? { paymentMethod: data.paymentMethod } : {}),
      ...(data.upiTxnRefId !== undefined ? { upiTxnRefId: data.upiTxnRefId } : {}),
      ...(data.receiptNumber ? { receiptNumber: data.receiptNumber } : {}),
      ...(data.purpose !== undefined ? { purpose: data.purpose } : {}),
      ...(data.notes !== undefined ? { notes: data.notes } : {}),
    },
  });

  await writeAuditLog({
    userId,
    action: "UPDATE",
    tableName: "donations",
    recordId: id,
    oldValue: existing,
    newValue: updated,
  });

  return serializeDonation(updated);
}

export async function deleteDonation(id: string, userId: string) {
  const existing = await prisma.donation.findFirst({ where: { id, deletedAt: null } });
  if (!existing) throw new AppError("Donation not found", 404);

  const deleted = await prisma.donation.update({
    where: { id },
    data: { deletedAt: new Date() },
  });

  await writeAuditLog({
    userId,
    action: "DELETE",
    tableName: "donations",
    recordId: id,
    oldValue: existing,
    newValue: deleted,
  });
}

function serializeDonation<T extends { amountPaise: bigint }>(donation: T) {
  return {
    ...donation,
    amountPaise: undefined,
    amount: Number(donation.amountPaise) / 100,
  };
}
