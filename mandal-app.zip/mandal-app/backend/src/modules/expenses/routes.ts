import { Router } from "express";
import { requireAuth } from "../../middleware/auth";
import { requireRole } from "../../middleware/role";
import { upload } from "../../middleware/upload";
import { create, getOne, list, remove, update } from "./controller";

export const expenseRouter = Router();

expenseRouter.use(requireAuth);

// All roles can view expenses.
expenseRouter.get("/", list);
expenseRouter.get("/:id", getOne);

// Only Admin & Treasurer can add/edit expenses; only Admin can delete
// (soft-delete), per the role permission matrix.
expenseRouter.post("/", requireRole("ADMIN", "TREASURER"), upload.single("billPhoto"), create);
expenseRouter.put("/:id", requireRole("ADMIN", "TREASURER"), upload.single("billPhoto"), update);
expenseRouter.delete("/:id", requireRole("ADMIN"), remove);
