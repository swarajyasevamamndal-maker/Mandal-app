import { z } from "zod";

export const paymentMethodEnum = z.enum(["CASH", "UPI", "BANK_TRANSFER", "OTHER"]);

export const createExpenseSchema = z.object({
  date: z.coerce.date(),
  categoryId: z.string().uuid("Invalid category"),
  description: z.string().min(2, "Description is required"),
  amount: z.coerce.number().positive("Amount must be greater than 0"),
  paymentMethod: paymentMethodEnum,
  paidById: z.string().uuid().optional(),
  vendorName: z.string().optional(),
  billNumber: z.string().optional(),
  billPhotoUrl: z.string().optional(),
  eventId: z.string().uuid().optional(),
  notes: z.string().optional(),
});

export const updateExpenseSchema = createExpenseSchema.partial();

export const expenseFilterSchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
  dateFrom: z.coerce.date().optional(),
  dateTo: z.coerce.date().optional(),
  categoryId: z.string().uuid().optional(),
  paymentMethod: paymentMethodEnum.optional(),
  search: z.string().optional(),
  sortBy: z.enum(["date", "amount"]).default("date"),
  sortOrder: z.enum(["asc", "desc"]).default("desc"),
});
