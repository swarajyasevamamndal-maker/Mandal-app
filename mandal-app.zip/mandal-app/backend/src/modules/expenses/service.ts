import { prisma } from "../../config/db";
import { AppError } from "../../middleware/errorHandler";
import { rupeesToPaise } from "../../utils/currency";
import { writeAuditLog } from "../../utils/audit";
import {
  createExpenseSchema,
  expenseFilterSchema,
  updateExpenseSchema,
} from "./validation";

export async function listExpenses(query: unknown) {
  const filters = expenseFilterSchema.parse(query);

  const where = {
    deletedAt: null,
    ...(filters.categoryId ? { categoryId: filters.categoryId } : {}),
    ...(filters.paymentMethod ? { paymentMethod: filters.paymentMethod } : {}),
    ...(filters.dateFrom || filters.dateTo
      ? {
          date: {
            ...(filters.dateFrom ? { gte: filters.dateFrom } : {}),
            ...(filters.dateTo ? { lte: filters.dateTo } : {}),
          },
        }
      : {}),
    ...(filters.search
      ? {
          OR: [
            { description: { contains: filters.search, mode: "insensitive" as const } },
            { vendorName: { contains: filters.search, mode: "insensitive" as const } },
            { billNumber: { contains: filters.search, mode: "insensitive" as const } },
          ],
        }
      : {}),
  };

  const [items, total] = await Promise.all([
    prisma.expense.findMany({
      where,
      include: { category: true, paidBy: { select: { id: true, name: true } }, event: true },
      orderBy: { [filters.sortBy === "amount" ? "amountPaise" : "date"]: filters.sortOrder },
      skip: (filters.page - 1) * filters.pageSize,
      take: filters.pageSize,
    }),
    prisma.expense.count({ where }),
  ]);

  return {
    items: items.map(serializeExpense),
    total,
    page: filters.page,
    pageSize: filters.pageSize,
  };
}

export async function getExpense(id: string) {
  const expense = await prisma.expense.findFirst({
    where: { id, deletedAt: null },
    include: { category: true, paidBy: { select: { id: true, name: true } }, event: true },
  });
  if (!expense) throw new AppError("Expense not found", 404);
  return serializeExpense(expense);
}

export async function createExpense(input: unknown, userId: string) {
  const data = createExpenseSchema.parse(input);

  const expense = await prisma.expense.create({
    data: {
      date: data.date,
      categoryId: data.categoryId,
      description: data.description,
      amountPaise: rupeesToPaise(data.amount),
      paymentMethod: data.paymentMethod,
      paidById: data.paidById,
      vendorName: data.vendorName,
      billNumber: data.billNumber,
      billPhotoUrl: data.billPhotoUrl,
      eventId: data.eventId,
      notes: data.notes,
      createdById: userId,
    },
  });

  await writeAuditLog({
    userId,
    action: "CREATE",
    tableName: "expenses",
    recordId: expense.id,
    newValue: expense,
  });

  return serializeExpense(expense);
}

export async function updateExpense(id: string, input: unknown, userId: string) {
  const data = updateExpenseSchema.parse(input);

  const existing = await prisma.expense.findFirst({ where: { id, deletedAt: null } });
  if (!existing) throw new AppError("Expense not found", 404);

  const updated = await prisma.expense.update({
    where: { id },
    data: {
      ...(data.date ? { date: data.date } : {}),
      ...(data.categoryId ? { categoryId: data.categoryId } : {}),
      ...(data.description ? { description: data.description } : {}),
      ...(data.amount !== undefined ? { amountPaise: rupeesToPaise(data.amount) } : {}),
      ...(data.paymentMethod ? { paymentMethod: data.paymentMethod } : {}),
      ...(data.paidById !== undefined ? { paidById: data.paidById } : {}),
      ...(data.vendorName !== undefined ? { vendorName: data.vendorName } : {}),
      ...(data.billNumber !== undefined ? { billNumber: data.billNumber } : {}),
      ...(data.billPhotoUrl !== undefined ? { billPhotoUrl: data.billPhotoUrl } : {}),
      ...(data.eventId !== undefined ? { eventId: data.eventId } : {}),
      ...(data.notes !== undefined ? { notes: data.notes } : {}),
    },
  });

  await writeAuditLog({
    userId,
    action: "UPDATE",
    tableName: "expenses",
    recordId: id,
    oldValue: existing,
    newValue: updated,
  });

  return serializeExpense(updated);
}

export async function deleteExpense(id: string, userId: string) {
  const existing = await prisma.expense.findFirst({ where: { id, deletedAt: null } });
  if (!existing) throw new AppError("Expense not found", 404);

  // Soft-delete: financial records are never hard-deleted, per audit
  // requirements. deletedAt is checked everywhere reads happen.
  const deleted = await prisma.expense.update({
    where: { id },
    data: { deletedAt: new Date() },
  });

  await writeAuditLog({
    userId,
    action: "DELETE",
    tableName: "expenses",
    recordId: id,
    oldValue: existing,
    newValue: deleted,
  });
}

function serializeExpense<T extends { amountPaise: bigint }>(expense: T) {
  return {
    ...expense,
    amountPaise: undefined,
    amount: Number(expense.amountPaise) / 100,
  };
}
