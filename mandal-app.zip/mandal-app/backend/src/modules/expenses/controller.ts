import { NextFunction, Request, Response } from "express";
import * as expenseService from "./service";

export async function list(req: Request, res: Response, next: NextFunction) {
  try {
    res.json(await expenseService.listExpenses(req.query));
  } catch (err) {
    next(err);
  }
}

export async function getOne(req: Request, res: Response, next: NextFunction) {
  try {
    res.json(await expenseService.getExpense(req.params.id));
  } catch (err) {
    next(err);
  }
}

export async function create(req: Request, res: Response, next: NextFunction) {
  try {
    const body = { ...req.body, billPhotoUrl: req.file ? `/uploads/${req.file.filename}` : req.body.billPhotoUrl };
    const expense = await expenseService.createExpense(body, req.user!.id);
    res.status(201).json(expense);
  } catch (err) {
    next(err);
  }
}

export async function update(req: Request, res: Response, next: NextFunction) {
  try {
    const body = { ...req.body, ...(req.file ? { billPhotoUrl: `/uploads/${req.file.filename}` } : {}) };
    const expense = await expenseService.updateExpense(req.params.id, body, req.user!.id);
    res.json(expense);
  } catch (err) {
    next(err);
  }
}

export async function remove(req: Request, res: Response, next: NextFunction) {
  try {
    await expenseService.deleteExpense(req.params.id, req.user!.id);
    res.status(204).send();
  } catch (err) {
    next(err);
  }
}
