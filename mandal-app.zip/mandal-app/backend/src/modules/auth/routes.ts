import { Router } from "express";
import { requireAuth } from "../../middleware/auth";
import { login, me, register } from "./controller";

export const authRouter = Router();

authRouter.post("/login", login);
// Registration is left open for the very first admin account; in
// production this should be locked down to admin-only after setup.
authRouter.post("/register", register);
authRouter.get("/me", requireAuth, me);
