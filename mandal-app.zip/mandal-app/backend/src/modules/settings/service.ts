import { prisma } from "../../config/db";
import { writeAuditLog } from "../../utils/audit";
import { updateSettingsSchema } from "./validation";

/** There is always exactly one settings row; create it on first access. */
export async function getSettings() {
  let settings = await prisma.settings.findFirst();
  if (!settings) {
    settings = await prisma.settings.create({
      data: { mandalName: "देवी मंडळ", deviName: "श्री देवी", financialYear: currentFinancialYear() },
    });
  }
  return settings;
}

export async function updateSettings(input: unknown, userId: string) {
  const data = updateSettingsSchema.parse(input);
  const existing = await getSettings();

  const updated = await prisma.settings.update({ where: { id: existing.id }, data });

  await writeAuditLog({
    userId,
    action: "UPDATE",
    tableName: "settings",
    recordId: existing.id,
    oldValue: existing,
    newValue: updated,
  });

  return updated;
}

export async function updateBrandingImage(
  field: "logoUrl" | "deviPhotoUrl",
  url: string,
  userId: string
) {
  const existing = await getSettings();
  const updated = await prisma.settings.update({
    where: { id: existing.id },
    data: { [field]: url },
  });

  await writeAuditLog({
    userId,
    action: "UPDATE",
    tableName: "settings",
    recordId: existing.id,
    oldValue: { [field]: existing[field] },
    newValue: { [field]: url },
  });

  return updated;
}

function currentFinancialYear(): string {
  const now = new Date();
  const year = now.getFullYear();
  const startYear = now.getMonth() >= 3 ? year : year - 1;
  const endYearShort = String((startYear + 1) % 100).padStart(2, "0");
  return `${startYear}-${endYearShort}`;
}
