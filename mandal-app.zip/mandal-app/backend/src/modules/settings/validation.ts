import { z } from "zod";

export const updateSettingsSchema = z.object({
  mandalName: z.string().min(1, "मंडळाचे नाव आवश्यक आहे").optional(),
  deviName: z.string().min(1, "देवीचे नाव आवश्यक आहे").optional(),
  address: z.string().optional(),
  contactNumber: z.string().optional(),
  financialYear: z.string().regex(/^\d{4}-\d{2}$/, "उदा. 2026-27 या format मध्ये टाका").optional(),
  currency: z.string().optional(),
  defaultLanguage: z.enum(["mr", "en"]).optional(),
});
