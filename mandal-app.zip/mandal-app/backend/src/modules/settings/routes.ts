import { NextFunction, Request, Response, Router } from "express";
import { requireAuth } from "../../middleware/auth";
import { requireRole } from "../../middleware/role";
import { upload } from "../../middleware/upload";
import { AppError } from "../../middleware/errorHandler";
import * as settingsService from "./service";

export const settingsRouter = Router();

// Public: the Login page needs mandal name / devi photo / logo before
// the user is authenticated. Only non-sensitive branding fields are
// exposed here, not the full settings row.
settingsRouter.get("/public", async (_req: Request, res: Response, next: NextFunction) => {
  try {
    const settings = await settingsService.getSettings();
    res.json({
      mandalName: settings.mandalName,
      deviName: settings.deviName,
      logoUrl: settings.logoUrl,
      deviPhotoUrl: settings.deviPhotoUrl,
    });
  } catch (err) {
    next(err);
  }
});

settingsRouter.use(requireAuth);

// Every logged-in user can read settings (Login page, header logo,
// receipt all need the branding info before/around auth).
settingsRouter.get("/", async (_req: Request, res: Response, next: NextFunction) => {
  try {
    res.json(await settingsService.getSettings());
  } catch (err) {
    next(err);
  }
});

settingsRouter.put("/", requireRole("ADMIN"), async (req: Request, res: Response, next: NextFunction) => {
  try {
    res.json(await settingsService.updateSettings(req.body, req.user!.id));
  } catch (err) {
    next(err);
  }
});

settingsRouter.post(
  "/devi-photo",
  requireRole("ADMIN"),
  upload.single("photo"),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      if (!req.file) throw new AppError("Photo file is required", 400);
      const url = `/uploads/${req.file.filename}`;
      const settings = await settingsService.updateBrandingImage("deviPhotoUrl", url, req.user!.id);
      res.json(settings);
    } catch (err) {
      next(err);
    }
  }
);

settingsRouter.post(
  "/logo",
  requireRole("ADMIN"),
  upload.single("logo"),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      if (!req.file) throw new AppError("Logo file is required", 400);
      const url = `/uploads/${req.file.filename}`;
      const settings = await settingsService.updateBrandingImage("logoUrl", url, req.user!.id);
      res.json(settings);
    } catch (err) {
      next(err);
    }
  }
);
