import "./utils/bigintJson";
import cors from "cors";
import express from "express";
import helmet from "helmet";
import { env } from "./config/env";
import { errorHandler } from "./middleware/errorHandler";
import { authRouter } from "./modules/auth/routes";
import { expenseRouter } from "./modules/expenses/routes";
import { donationRouter } from "./modules/donations/routes";
import { upiTransactionRouter } from "./modules/upi-transactions/routes";
import { dashboardRouter } from "./modules/dashboard/routes";
import { categoryRouter } from "./modules/categories/routes";
import { settingsRouter } from "./modules/settings/routes";
import { memberRouter } from "./modules/members/routes";

const app = express();

// helmet's default Cross-Origin-Resource-Policy is "same-origin", which
// would block the Android app (a different origin than this API) from
// loading uploaded images — Devi photo, bill photos, screenshots, etc.
// via <img src="https://api.../uploads/...">. Relaxed to cross-origin
// since this backend is meant to serve a separate frontend origin.
app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(cors());
app.use(express.json());
app.use("/uploads", express.static(env.uploadDir));

app.get("/api/v1/health", (_req, res) => res.json({ status: "ok" }));

app.use("/api/v1/auth", authRouter);
app.use("/api/v1/expenses", expenseRouter);
app.use("/api/v1/donations", donationRouter);
app.use("/api/v1/upi-transactions", upiTransactionRouter);
app.use("/api/v1/dashboard", dashboardRouter);
app.use("/api/v1/categories", categoryRouter);
app.use("/api/v1/settings", settingsRouter);
app.use("/api/v1/members", memberRouter);
// Remaining modules (events, tasks, reports, notifications, audit-logs
// list endpoint) follow the same pattern and will be added the same way.

// Must be registered last so it catches errors from every route above.
app.use(errorHandler);

app.listen(env.port, () => {
  console.log(`Mandal app backend running on http://localhost:${env.port}`);
});
