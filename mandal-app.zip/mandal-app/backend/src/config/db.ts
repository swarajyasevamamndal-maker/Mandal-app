import { PrismaClient } from "@prisma/client";

// Single shared Prisma instance across the app (avoids exhausting DB
// connections when the dev server hot-reloads).
declare global {
  // eslint-disable-next-line no-var
  var __prisma: PrismaClient | undefined;
}

export const prisma = global.__prisma || new PrismaClient();

if (env_is_dev()) {
  global.__prisma = prisma;
}

function env_is_dev() {
  return process.env.NODE_ENV !== "production";
}
