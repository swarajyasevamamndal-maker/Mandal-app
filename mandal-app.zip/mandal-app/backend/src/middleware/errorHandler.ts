import { NextFunction, Request, Response } from "express";
import { ZodError } from "zod";

export class AppError extends Error {
  statusCode: number;
  constructor(message: string, statusCode = 400) {
    super(message);
    this.statusCode = statusCode;
  }
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function errorHandler(err: unknown, req: Request, res: Response, next: NextFunction) {
  if (err instanceof ZodError) {
    return res.status(400).json({
      error: "Validation failed",
      details: err.errors.map((e) => ({ field: e.path.join("."), message: e.message })),
    });
  }

  if (err instanceof AppError) {
    return res.status(err.statusCode).json({ error: err.message });
  }

  // Prisma unique constraint violation (e.g. duplicate UTR number)
  if (typeof err === "object" && err !== null && "code" in err && (err as any).code === "P2002") {
    const target = (err as any).meta?.target?.join(", ") ?? "field";
    return res.status(409).json({ error: `${target} already exists (must be unique)` });
  }

  console.error(err);
  return res.status(500).json({ error: "Internal server error" });
}
