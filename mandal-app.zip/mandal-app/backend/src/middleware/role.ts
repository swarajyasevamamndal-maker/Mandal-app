import { NextFunction, Request, Response } from "express";
import { AuthUser } from "./auth";

/**
 * Usage: router.post("/", requireAuth, requireRole("ADMIN", "TREASURER"), handler)
 * Must run after requireAuth so req.user is populated.
 */
export function requireRole(...allowed: AuthUser["role"][]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: "Authentication required" });
    }
    if (!allowed.includes(req.user.role)) {
      return res.status(403).json({ error: "You do not have permission to perform this action" });
    }
    next();
  };
}
