/**
 * All amounts are stored in the database as BigInt paise (smallest INR
 * unit) to avoid floating point rounding errors in financial totals.
 * These helpers convert between the rupee amounts the UI/API works
 * with and the paise values stored in the DB.
 */

export function rupeesToPaise(rupees: number): bigint {
  if (!Number.isFinite(rupees)) {
    throw new Error("Invalid amount");
  }
  // Round to nearest paisa before converting to avoid float drift.
  return BigInt(Math.round(rupees * 100));
}

export function paiseToRupees(paise: bigint | number): number {
  const p = typeof paise === "bigint" ? Number(paise) : paise;
  return Math.round(p) / 100;
}

export function formatInr(paise: bigint | number): string {
  const rupees = paiseToRupees(paise);
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 2,
  }).format(rupees);
}
