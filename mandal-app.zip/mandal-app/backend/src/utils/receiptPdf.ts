import fs from "fs";
import path from "path";
import { PDFDocument, rgb, StandardFonts } from "pdf-lib";
// fontkit is required so pdf-lib can embed a custom TTF (Devanagari
// script isn't covered by pdf-lib's built-in Latin-only StandardFonts).
import fontkit from "@pdf-lib/fontkit";
import { formatInr } from "./currency";
import { env } from "../config/env";

interface ReceiptInput {
  mandalName: string;
  deviName: string;
  logoUrl?: string;
  deviPhotoUrl?: string;
  donorName: string;
  date: Date;
  receiptNumber: string;
  amountPaise: bigint;
  paymentMethod: string;
  utrNumber?: string;
  authorizedPerson: string;
}

const DEVANAGARI_FONT_PATH = path.resolve(__dirname, "../../assets/fonts/NotoSansDevanagari-Regular.ttf");
// The Settings "Change Logo" upload saves files via multer into
// env.uploadDir (backend/uploads), served publicly at /uploads/<file>.
// settings.logoUrl stores that "/uploads/<file>" path, so the logo
// must be read back from the same directory multer wrote it to.
const LOGO_DIR = path.resolve(process.cwd(), env.uploadDir);

export async function generateReceiptPdf(input: ReceiptInput): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.create();
  pdfDoc.registerFontkit(fontkit);

  // Marathi text (mandal name, devi name, labels) needs a Devanagari
  // font; English/numeric fields can fall back to a standard font if
  // the Devanagari TTF hasn't been placed yet, so the receipt still
  // generates instead of crashing.
  const hasDevanagariFont = fs.existsSync(DEVANAGARI_FONT_PATH);
  const marathiFont = hasDevanagariFont
    ? await pdfDoc.embedFont(fs.readFileSync(DEVANAGARI_FONT_PATH), { subset: true })
    : await pdfDoc.embedFont(StandardFonts.Helvetica);
  const englishFont = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const englishBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

  const page = pdfDoc.addPage([595.28, 419.53]); // A5 landscape — standard receipt size
  const { width, height } = page.getSize();

  const margin = 36;
  let y = height - margin;

  // Border
  page.drawRectangle({
    x: margin / 2,
    y: margin / 2,
    width: width - margin,
    height: height - margin,
    borderColor: rgb(0.75, 0.55, 0.1),
    borderWidth: 1.5,
  });

  // Logo (top-left), if uploaded via Settings
  if (input.logoUrl) {
    await tryDrawImage(pdfDoc, page, input.logoUrl, { x: margin + 6, yTop: y, maxWidth: 40 });
  }

  // Devi photo (top-right), if uploaded via Settings — a respectful,
  // modest placement rather than a large dominant image.
  if (input.deviPhotoUrl) {
    await tryDrawImage(pdfDoc, page, input.deviPhotoUrl, {
      x: width - margin - 44,
      yTop: y,
      maxWidth: 40,
    });
  }

  // Header: Mandal name + Devi name, centered
  drawCentered(page, input.mandalName, marathiFont, 20, width, y, rgb(0.55, 0.15, 0.15));
  y -= 26;
  drawCentered(page, input.deviName, marathiFont, 13, width, y, rgb(0.3, 0.3, 0.3));
  y -= 18;
  drawCentered(page, "देणगी पावती / Donation Receipt", marathiFont, 12, width, y, rgb(0, 0, 0));
  y -= 30;

  page.drawLine({
    start: { x: margin, y },
    end: { x: width - margin, y },
    thickness: 0.75,
    color: rgb(0.75, 0.55, 0.1),
  });
  y -= 24;

  const rowGap = 22;
  const labelX = margin + 8;
  const valueX = 230;

  const rows: [string, string][] = [
    ["Receipt No.", input.receiptNumber],
    ["Date", input.date.toLocaleDateString("en-IN")],
    ["Donor Name", input.donorName],
    ["Amount", formatInr(input.amountPaise)],
    ["Payment Method", input.paymentMethod.replace("_", " ")],
    ...(input.utrNumber ? ([["UTR / Transaction ID", input.utrNumber]] as [string, string][]) : []),
  ];

  for (const [label, value] of rows) {
    page.drawText(label, { x: labelX, y, size: 11, font: englishBold, color: rgb(0.2, 0.2, 0.2) });
    page.drawText(":", { x: valueX - 12, y, size: 11, font: englishBold });
    page.drawText(String(value), { x: valueX, y, size: 11, font: englishFont, color: rgb(0, 0, 0) });
    y -= rowGap;
  }

  y -= 20;
  page.drawText("Authorized Person:", { x: labelX, y, size: 10, font: englishBold });
  page.drawText(input.authorizedPerson, { x: valueX, y, size: 10, font: englishFont });

  page.drawText(
    "धन्यवाद! आपल्या देणगीबद्दल मंडळ आभारी आहे. / Thank you for your generous contribution.",
    { x: margin + 8, y: margin + 14, size: 9, font: marathiFont, color: rgb(0.4, 0.4, 0.4) }
  );

  return pdfDoc.save();
}

function drawCentered(
  page: import("pdf-lib").PDFPage,
  text: string,
  font: import("pdf-lib").PDFFont,
  size: number,
  pageWidth: number,
  y: number,
  color: ReturnType<typeof rgb>
) {
  const textWidth = font.widthOfTextAtSize(text, size);
  page.drawText(text, { x: (pageWidth - textWidth) / 2, y, size, font, color });
}

/**
 * Loads an uploaded image (stored under env.uploadDir, referenced as
 * "/uploads/<file>") and draws it on the page. Silently no-ops if the
 * file is missing or unreadable — a receipt must still generate even
 * if a branding image was deleted or is corrupt.
 */
async function tryDrawImage(
  pdfDoc: PDFDocument,
  page: import("pdf-lib").PDFPage,
  imageUrl: string,
  opts: { x: number; yTop: number; maxWidth: number }
) {
  const filePath = path.resolve(LOGO_DIR, path.basename(imageUrl));
  if (!fs.existsSync(filePath)) return;

  try {
    const bytes = fs.readFileSync(filePath);
    const lower = filePath.toLowerCase();
    const image = lower.endsWith(".png") ? await pdfDoc.embedPng(bytes) : await pdfDoc.embedJpg(bytes);
    const dim = image.scale(opts.maxWidth / image.width);
    page.drawImage(image, { x: opts.x, y: opts.yTop - dim.height, width: dim.width, height: dim.height });
  } catch {
    // Corrupt or unsupported image format — skip silently.
  }
}
