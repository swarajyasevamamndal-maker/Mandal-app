/**
 * Node's JSON.stringify throws "Do not know how to serialize a BigInt"
 * for any BigInt value — and several Prisma models store amounts as
 * BigInt paise (see schema.prisma). Per-response serializer functions
 * convert the *top-level* amount field already, but a nested relation
 * (e.g. an Expense's linked Event, once the Events module exists) could
 * still carry a raw BigInt and crash res.json(). This safety net
 * ensures any BigInt anywhere in a response serializes as a string
 * instead of crashing the request.
 *
 * Must be imported before any route handles a request — imported first
 * thing in server.ts.
 */
(BigInt.prototype as unknown as { toJSON: () => string }).toJSON = function (this: bigint) {
  return this.toString();
};
