import { prisma } from "../config/db";

type AuditAction = "CREATE" | "UPDATE" | "DELETE";

interface AuditInput {
  userId: string;
  action: AuditAction;
  tableName: string;
  recordId: string;
  oldValue?: unknown;
  newValue?: unknown;
}

/**
 * Serializes BigInt fields (paise amounts) safely before storing in the
 * JSON audit columns, since JSON.stringify can't handle BigInt natively.
 */
function serialize(value: unknown) {
  if (value === undefined) return undefined;
  return JSON.parse(
    JSON.stringify(value, (_key, v) => (typeof v === "bigint" ? v.toString() : v))
  );
}

export async function writeAuditLog(input: AuditInput) {
  await prisma.auditLog.create({
    data: {
      userId: input.userId,
      action: input.action,
      tableName: input.tableName,
      recordId: input.recordId,
      oldValue: serialize(input.oldValue) ?? undefined,
      newValue: serialize(input.newValue) ?? undefined,
    },
  });
}
