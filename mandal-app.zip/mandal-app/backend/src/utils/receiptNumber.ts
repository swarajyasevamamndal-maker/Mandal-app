import { prisma } from "../config/db";

/**
 * Generates receipt numbers like "DM-2026-27-0001", sequential per
 * financial year. Falls back to a plain "2026-27" prefix if Settings
 * hasn't been configured yet.
 */
export async function generateReceiptNumber(): Promise<string> {
  const settings = await prisma.settings.findFirst();
  const financialYear = settings?.financialYear || currentFinancialYear();
  const prefix = `DM-${financialYear}`;

  const count = await prisma.donation.count({
    where: { receiptNumber: { startsWith: prefix } },
  });

  const next = String(count + 1).padStart(4, "0");
  return `${prefix}-${next}`;
}

function currentFinancialYear(): string {
  const now = new Date();
  const year = now.getFullYear();
  // Indian financial year: April to March.
  const startYear = now.getMonth() >= 3 ? year : year - 1;
  const endYearShort = String((startYear + 1) % 100).padStart(2, "0");
  return `${startYear}-${endYearShort}`;
}
