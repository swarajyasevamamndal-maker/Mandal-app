# देवी मंडळ App — Backend

## Setup

```bash
cd backend
npm install
cp .env.example .env
# .env मध्ये तुमचा PostgreSQL DATABASE_URL आणि JWT_SECRET टाका

npx prisma migrate dev --name init   # सर्व tables तयार करेल (fresh DB — एकच command पुरेसे आहे)
npm run prisma:seed                  # 14 default expense categories + पहिली settings row
npm run dev                          # http://localhost:4000 वर server सुरू होईल
```

## आत्तापर्यंत तयार आहे

- **Database schema** (`prisma/schema.prisma`) — सर्व tables, relations, soft-delete, paise-based amounts
- **Auth module** — JWT login/register, bcrypt password hashing
- **Expense module** — पूर्ण CRUD, role-based access, bill photo upload, pagination/search/filter/sort, audit log, soft-delete
- **Donations module** — पूर्ण CRUD, auto receipt numbers (financial-year scoped), soft-delete, audit log
- **UPI Transactions module** — duplicate UTR check (pre-check + DB-level unique constraint), audit log
- **Receipt PDF** — `/donations/:id/receipt`
- **Dashboard summary** — `/dashboard/summary` (server-side aggregation — cash/UPI/bank/total balance, monthly income vs expense, recent activity)
- **Categories module** — list (active/all), add, edit, deactivate; seeded with 14 default categories
- **Settings module** — mandal branding, Devi photo upload, Logo upload; `/settings/public` is unauthenticated
- **Members module** — CRUD, soft-delete, photo upload, admin-managed

⚠️ Devanagari font अजून manual step आहे — बघा `assets/fonts/README.md`.

## पहिला Admin user तयार करणे

Migration नंतर एकदा `/api/v1/auth/register` वर call करून `role: "ADMIN"` सह पहिला admin account तयार करा. त्यानंतर production मध्ये हे endpoint admin-only करावे (routes.ts मध्ये comment केले आहे).

## पुढील Modules (अजून तयार नाहीत)

Events · Tasks · Reports (+ PDF/Excel export) · Notifications · Audit Logs (list/view endpoint — logging आधीच होते आहे, फक्त बघण्यासाठी screen/API नाही)

प्रत्येक module मध्ये: `validation.ts` (zod schema) → `service.ts` (business logic + audit log) → `controller.ts` (HTTP handlers) → `routes.ts` (role-based routing) — Expense module प्रमाणेच.

## Test करणे (उदा. curl)

```bash
# Register admin
curl -X POST http://localhost:4000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Admin","email":"admin@mandal.org","password":"secret123","role":"ADMIN"}'

# Login
curl -X POST http://localhost:4000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@mandal.org","password":"secret123"}'

# Add expense (टोकन login response मधून घ्या)
curl -X POST http://localhost:4000/api/v1/expenses \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"date":"2026-08-14","categoryId":"<category-uuid>","description":"Flowers","amount":1500,"paymentMethod":"CASH"}'
```
