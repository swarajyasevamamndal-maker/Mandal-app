# Fonts

Marathi (Devanagari) text on the PDF receipt needs a Unicode Devanagari
font — pdf-lib's built-in fonts only cover Latin script.

**Required step (I could not download this file — no internet access
in this environment):**

1. Download **Noto Sans Devanagari** (free, open-source) from Google Fonts:
   https://fonts.google.com/noto/specimen/Noto+Sans+Devanagari
2. Place the regular-weight file here as:
   `backend/assets/fonts/NotoSansDevanagari-Regular.ttf`

Until this file is added, `receiptPdf.ts` automatically falls back to a
Latin-only font so PDF generation still works — but Marathi labels on
the receipt (मंडळाचे नाव, देवीचे नाव, etc.) will render as blank boxes
until the real font is in place.
