import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const defaultCategories: { nameMr: string; nameEn: string; sortOrder: number }[] = [
  { nameMr: "सजावट", nameEn: "Decoration", sortOrder: 1 },
  { nameMr: "साऊंड सिस्टीम", nameEn: "Sound System", sortOrder: 2 },
  { nameMr: "लाईट", nameEn: "Light", sortOrder: 3 },
  { nameMr: "स्टेज / मंडप", nameEn: "Stage / Mandap", sortOrder: 4 },
  { nameMr: "फुले", nameEn: "Flowers", sortOrder: 5 },
  { nameMr: "प्रसाद", nameEn: "Prasad", sortOrder: 6 },
  { nameMr: "भोजन", nameEn: "Food", sortOrder: 7 },
  { nameMr: "जाहिरात", nameEn: "Advertisement", sortOrder: 8 },
  { nameMr: "वाहतूक", nameEn: "Transport", sortOrder: 9 },
  { nameMr: "वीज", nameEn: "Electricity", sortOrder: 10 },
  { nameMr: "पूजा साहित्य", nameEn: "Pooja Material", sortOrder: 11 },
  { nameMr: "स्वच्छता", nameEn: "Cleaning", sortOrder: 12 },
  { nameMr: "सांस्कृतिक कार्यक्रम", nameEn: "Cultural Program", sortOrder: 13 },
  { nameMr: "इतर", nameEn: "Other", sortOrder: 14 },
];

async function main() {
  for (const cat of defaultCategories) {
    const existing = await prisma.category.findFirst({
      where: { nameEn: cat.nameEn, type: "expense" },
    });
    if (!existing) {
      await prisma.category.create({ data: { ...cat, type: "expense" } });
      console.log(`Created category: ${cat.nameEn}`);
    }
  }

  const settings = await prisma.settings.findFirst();
  if (!settings) {
    await prisma.settings.create({
      data: {
        mandalName: "देवी मंडळ",
        deviName: "श्री देवी",
        financialYear: "2026-27",
      },
    });
    console.log("Created default settings row");
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
